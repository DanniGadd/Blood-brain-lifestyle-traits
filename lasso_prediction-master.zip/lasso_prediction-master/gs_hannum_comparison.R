# Shockwave
# working dir: "s1145471/Hannum"
require(dplyr)
require(ggplot2)
require(IlluminaHumanMethylationEPICanno.ilm10b2.hg19)
data(IlluminaHumanMethylationEPICanno.ilm10b2.hg19)
data(Other)

hannum <- read.table("GSE40728_average_beta.txt", sep='\t', header=T)
hannum_age <- read.csv("sample.csv", sep=',', header=T)
hannum_age$Samp <- gsub(".*y ", "", hannum_age[,2]) %>% as.numeric
hannum_age[,2] <- gsub("age |y.*", "", hannum_age[,2]) %>% as.numeric

pdf("Hannum_age.pdf")
hist(age[,2], breaks=100, xlab="Age", main="Age", col="grey")
dev.off()

# Predict GS age in Hannum
load("Age_LASSO_coefficients_25Jan2018.RData")
hannum2 <- hannum
rownames(hannum) <- hannum[,1]
hannum <- hannum[,-1]
a <- which(rownames(hannum) %in% coef$coef.name)

meth2 = hannum[a,]

probes <- intersect(coef$coef.name, rownames(meth2))
rownames(coef) = coef$coef.name

b = meth2[probes,]
p = coef[probes,]

for (i in probes) {
    b[i,]= b[i,]*p[i,"coef.value"]
}

predicted_age=colSums(b) + coef[1,2]
pred_age = as.data.frame(predicted_age)
pred_age$Basename = rownames(pred_age)
pred_age$Basename <- gsub("X", "", pred_age$Basename)
pred_age$Actual_age <- age[match(pred_age$Basename), age$Samp), "Title"]

pdf("GS_Hannum_cor.pdf")
plot(pred_age$Actual_age, pred_age$predicted_age, 
     xlab="Actual age (Hannum)", ylab="Predicted age (GS)")
dev.off()

#Plot overlayed histograms
load("GS_chronological_ages_for_LASSO_26Jan2018.RData")

plotdata <- data.frame(Age=c(age$Age, hannum_age$Title), 
                       Data=c(rep("GS", nrow(age)), 
					          rep("Hannum", nrow(hannum_age))))

pdf("age_densityplots.pdf")
ggplot(data=plotdata, aes(x=Age, fill=Data)) + 
geom_density(alpha=0.25)
dev.off()

pdf("age_histograms.pdf")
ggplot(data=plotdata, aes(x=Age, fill=Data)) + 
geom_histogram(alpha=0.25)
dev.off()

save.image("Hannum_GS_age_comparison.RData")

# Annotate coefficients
coef$Gene <- Other[match(rownames(coef), rownames(Other)), "UCSC_RefGene_Name"]
genes1 <- coef$Gene %>% str_split(";")
genes2 <- lapply(genes1, function(x){levels(factor(x))})
genes3 <- unlist(genes2) %>% unique
genes3 <- genes3[-which(genes3=="")]

hannum_probes <- read.table("hannum_probes.txt", header=T, sep='\t')

probeoverlap <- coef[intersect(hannum_probes$Marker, rownames(coef)),]

# Extract Hannum probe genes from manifest for consistency
hannum_probes$Gene2 <- Other[match(hannum_probes$Marker, rownames(Other)), 
                        "UCSC_RefGene_Name"]
                        
hannumgenes1 <- hannum_probes$Gene2 %>% str_split(";")
hannumgenes2 <- lapply(hannumgenes1, function(x){levels(factor(x))})
hannumgenes3 <- unlist(hannumgenes2) %>% unique
hannumgenes3 <- hannumgenes3[-which(hannumgenes3=="")]
geneoverlap <- intersect(genes3, hannumgenes3)

# Make background gene set for pathway analysis
bg <- Other$UCSC_RefGene_Name %>% str_split(";") %>% 
      unlist %>% unique 
bg <- bg[-which(bg=="")]

write.table(data.frame(genes3), file="GS_TargetGenes.xls", sep='\t', col.names=F, row.names=F)
write.table(data.frame(hannumgenes3), file="Hannum_TargetGenes.xls", sep='\t', col.names=F, row.names=F)
write.table(data.frame(bg), file="Background.xls", sep='\t', col.names=F, row.names=F)
write.table(data.frame(geneoverlap), file="GS_Hannum_overlap.xls", sep='\t', col.names=F, row.names=F)

# Ran GORilla on target and background sets
# GS GO
gs_component <- read.table("GS_GOCOMPONENT.xls", sep='\t', header=T)[,1:4]
gs_process <- read.table("GS_GOPROCESS.xls", sep='\t', header=T)[,1:4]
gs_function <- read.table("GS_GOFUNCTION.xls", sep='\t', header=T)[,1:4]
gs_go <- rbind(gs_component, gs_process, gs_function)

# Hannum GO
hannum_component <- read.table("Hannum_GOCOMPONENT.xls", sep='\t', header=T)[,1:4]
hannum_process <- read.table("Hannum_GOPROCESS.xls", sep='\t', header=T)[,1:4]
hannum_function <- read.table("Hannum_GOFUNCTION.xls", sep='\t', header=T)[,1:4]
hannum_go <- rbind(hannum_component, hannum_process, hannum_function)

# Overlap GO
overlap_component <- read.table("Overlap_GOCOMPONENT.xls", sep='\t', header=T)[,1:4]
overlap_process <- read.table("Overlap_GOPROCESS.xls", sep='\t', header=T)[,1:4]
overlap_go <- rbind(overlap_component, overlap_process)

# Is overlap between GS and Hannum genes 
array_overlap <- intersect(rownames(Other), rownames(hannum))
phyper(nrow(overlap)-1, length(rownames(coef)[-1]), length(array_overlap), 
       nrow(hannum_probes), lower.tail=F)

# Plot error
pred_age$Delta <- pred_age$predicted_age - pred_age$Actual_age
pdf("delta_histogram.pdf")
ggplot(data=pred_age, aes(x=Delta)) + 
geom_histogram(alpha=0.9)
dev.off()

pred_age$Residual <- resid(lm(pred_age$predicted_age~pred_age$Actual_age))
pdf("resid_histogram.pdf")
ggplot(data=pred_age, aes(x=Residual)) + 
geom_histogram(alpha=0.9)
dev.off()

