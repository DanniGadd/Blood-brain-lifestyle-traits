setwd("Z:/Daniel/Forensic_methylation_Feb2018")
source("functions.R")
library(ggplot2)
library(rms)
library(survival)
library(pROC)
library(reshape2)
library(dplyr)
library(RColorBrewer)
library(gplots)
library(MASS)
library(gridExtra)
library(ggpubr)
library(cowplot)
library(foreign)
library(plotROC)

# Load 'd4' object
load("GS_descriptives_for_LASSO_15Feb2018.RData")

# Load 'pg' object
load("Epi_signatures_of_death_15Feb2018.RData")



m0 =  summary(lm(bmi ~ age + sex, data=pg))
m1 =  summary(lm(bmi ~ age + sex + scale(predicted_bmi) + scale(bmi_pgrs), data=pg))
m2 =  summary(lm(bmi ~ age + sex + scale(predicted_bmi), data=pg))
m3 =  summary(lm(bmi ~ age + sex + scale(bmi_pgrs), data=pg))
bmi_r_add <- 100*(m1$r.squared - m0$r.squared)
bmi_r_meth <- 100*(m2$r.squared - m0$r.squared)
bmi_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

m0 =  summary(lm(EA ~ age + sex, data=pg))
m1 =  summary(lm(EA ~ age + sex + scale(predicted_ea) + scale(ea_pgrs), data=pg))
m2 =  summary(lm(EA ~ age + sex + scale(predicted_ea), data=pg))
m3 =  summary(lm(EA ~ age + sex + scale(ea_pgrs), data=pg))
ea_r_add <- 100*(m1$r.squared - m0$r.squared)
ea_r_meth <- 100*(m2$r.squared - m0$r.squared)
ea_r_pgrs <- 100*(m3$r.squared - m0$r.squared)



m0 = orm(smk ~ age + sex, data=pg)
m1 = orm(smk ~ age + sex + scale(smk_pgrs) + scale(predicted_smk), data=pg)
m2 = orm(smk ~ age + sex + scale(predicted_smk), data=pg)
m3 = orm(smk ~ age + sex + scale(smk_pgrs), data=pg)
smk_r_add <- 100*(m1[["stats"]]["R2"] - m0[["stats"]]["R2"])
smk_r_meth <- 100*(m2[["stats"]]["R2"] - m0[["stats"]]["R2"])
smk_r_pgrs <- 100*(m3[["stats"]]["R2"] - m0[["stats"]]["R2"])

# Smoking pack years
lbc36 <- read.spss("LBC1936_EWAS_MetaAnalysis_COPD_RM_29MAR2018.sav", to.data.frame=TRUE)
lbc36$lbc36no <- gsub(" ", "", lbc36$lbc36no)
lbc36 <- lbc36[which(lbc36$lbc36no %in% pg$ID),]
rownames(lbc36) <- pg$ID[match(lbc36$lbc36no, pg$ID)] %>% na.omit
lbc36$packyears <- NA
for(i in 1:nrow(lbc36)){
  if(isTRUE(lbc36$smokcat_w1[i]) == "never smoked") { 
    lbc36$packyears[i] <- 0
	} else if(isTRUE(lbc36$smokcat_w1[i] == "ex-smoker")) {
	  lbc36$packyears[i] <- lbc36$smoknumcigs_w1[i]/20 * (lbc36$smokagestop_w1[i] - lbc36$smokagestart_w1[i])
	  } else if(isTRUE(lbc36$smokcat_w1[i] == "current smoker")) { 
	    lbc36$packyears[i] <- lbc36$smoknumcigs_w1[i]/20 * ((lbc36$agedays_w1[i]/365.25) - (lbc36$smokagestart_w1[i]))
	    } 
  }
lbc36[which(is.na(lbc36$packyears)), "packyears"] <- 0
lbc36[which(lbc36$smokcat_w1 %in% c("current smoker", "ex-smoker") & 
            is.na(lbc36$smoknumcigs_w1)),"packyears"] <- NA
			
lbc36[which(lbc36$smokcat_w1 %in% c("current smoker", "ex-smoker") & 
            is.na(lbc36$smokagestop_w1 | lbc36$smokagestart_w1)),"packyears"] <- NA
lbc36[which(lbc36$smokcat_w1=="ex-smoker" &  is.na(lbc36$smokagestart_w1)),"packyears"] <- NA
lbc36[which(lbc36$smokcat_w1=="ex-smoker" &  is.na(lbc36$smokagestop_w1)),"packyears"] <- NA
pg$packyears <- lbc36[match(pg$ID, lbc36$lbc36no), "packyears"]
pg$packyears <- log(pg$packyears + 1)

m0 =  summary(lm(packyears ~ age + sex, data=pg))
m1 =  summary(lm(packyears ~ age + sex + scale(predicted_smk) + scale(smk_pgrs), data=pg))
m2 =  summary(lm(packyears ~ age + sex + scale(predicted_smk), data=pg))
m3 =  summary(lm(packyears ~ age + sex + scale(smk_pgrs), data=pg))
packyears_r_add <- 100*(m1$r.squared - m0$r.squared)
packyears_r_meth <- 100*(m2$r.squared - m0$r.squared)
packyears_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

m0 =  summary(lm(alc ~ age + sex, data=pg))
m1 =  summary(lm(alc ~ age + sex + scale(predicted_alc) + scale(alc_pgrs), data=pg))
m2 =  summary(lm(alc ~ age + sex + scale(predicted_alc), data=pg))
m3 =  summary(lm(alc ~ age + sex + scale(alc_pgrs), data=pg))
alc_r_add <- 100*(m1$r.squared - m0$r.squared)
alc_r_meth <- 100*(m2$r.squared - m0$r.squared)
alc_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

plot_data <- data.frame("Phenotype"=c(rep("BMI", 3), rep("Education", 3),  
                                      rep("Smoking", 3), rep("Alcohol", 3)),
		                "Score" = rep(c("DNAm", "Polygenic", 
						                "Polygenic + DNAm"), 4),
		                "R2" = c(bmi_r_meth, bmi_r_pgrs, bmi_r_add, 
		                         ea_r_meth, ea_r_pgrs, ea_r_add,
					             smk_r_meth, smk_r_pgrs, smk_r_add,
					             alc_r_meth, alc_r_pgrs, alc_r_add))
plot_data$Phenotype <- factor(plot_data$Phenotype, levels=c("BMI", "Smoking", 
                              "Alcohol", "Education"))
plot_data$Score <- factor(plot_data$Score, levels=c("Polygenic", "DNAm", "Polygenic + DNAm"))

pdf("R2_plot.pdf")
ggplot(data=plot_data, aes(x=Phenotype, y=R2, colour=Score, 
       fill=Score)) + 
geom_bar(stat="identity", position="dodge", colour="black") + 
scale_fill_manual(values= brewer.pal(9, "Paired")[c(1,3,7)]) + 
ylab(expression(R^{2})) +
theme(legend.position = c(0.9,0.9)) + 
scale_y_continuous(breaks = seq(0,60,10))
# ggtitle(paste("Variance Explained by Score")) + 
# theme(plot.title = element_text(hjust = 0.5))
dev.off()

cor.test(pg$predicted_ea, pg$ea_pgrs)
cor.test(pg$predicted_smk, pg$smk_pgrs)
cor.test(pg$predicted_bmi, pg$bmi_pgrs)
cor.test(pg$predicted_alc, pg$alc_pgrs)

# Read in updated survival data
dead <- read.spss("LBC1936_MortalityDataUpdate_RM_27FEB2018.sav", to.data.frame=T)

dead$age_event = ifelse(!is.na(dead$agedays_death), 
                 dead$agedays_death, 
                 dead$agedaysApx_LastCensor)
dead$event = ifelse(is.na(dead$dead), 0, 1)

dead$lbc36no = trimws(dead$lbc36no, which = c("right"))

pg = merge(pg[,c(1:15,18:21)], dead[,c(1,6,7)], by.x="ID", by.y="lbc36no")
pg$age_event <- pg$age_event/365.25

cox_bmi <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi), data=pg))
cox_bmi_pgrs <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi_pgrs), data=pg))
cox_bmi_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_bmi), data=pg))
cox_bmipheno_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi) + scale(predicted_bmi), data=pg))

cox_alc <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc), data=pg))
cox_alc_pgrs <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc_pgrs), data=pg))
cox_alc_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_alc), data=pg))
cox_alcpheno_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc) + scale(predicted_alc), data=pg))

cox_smk <- summary(coxph(Surv(age, age_event, event) ~ sex + factor(smk), data=pg))
cox_smk_pgrs <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(smk_pgrs), data=pg))
cox_smk_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_smk), data=pg))
cox_smkpheno_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + factor(smk) + scale(predicted_smk), data=pg))

cox_ea <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(EA), data=pg))
cox_ea_pgrs <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(ea_pgrs), data=pg))
cox_ea_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_ea), data=pg))
# cox_ea_pgrs_meth <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(EA) + scale(predicted_ea), data=pg))

# Conditioned models
cox_bmi_cond <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi) + scale(predicted_bmi), data=pg))
cox_smk_cond <- summary(coxph(Surv(age, age_event, event) ~ sex + factor(smk) + scale(predicted_smk), data=pg))
cox_alc_cond <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc) + scale(predicted_alc), data=pg))
cox_ea_cond <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(EA) + scale(predicted_ea), data=pg))

# Conditioned models (smoking)
cox_bmi_cond_smk <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi) + scale(predicted_bmi) + scale(predicted_smk), data=pg))
cox_alc_cond_smk <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc) + scale(predicted_alc) + scale(predicted_smk), data=pg))
cox_ea_cond_smk <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(EA) + scale(predicted_ea) + scale(predicted_smk), data=pg))


# Tabulate statistics
bmi_mat <- alc_mat <- ea_mat <- matrix(nrow=3, ncol=3)
rownames(bmi_mat) <- c("HR", "95% CI", "P")
colnames(bmi_mat) <- c("Phenotypic", "Epigenetic", "Genetic")
dimnames(alc_mat) <- dimnames(ea_mat) <- dimnames(bmi_mat)

smk_mat <- matrix(nrow=3, ncol=4)
rownames(smk_mat) <- rownames(alc_mat)
colnames(smk_mat) <- c("Phenotypic_Former", "Phenotypic_Current", "Epigenetic", "Genetic")
bmi_mat[1,] <- c(signif(cox_bmi$conf.int[2,1],3), 
                 signif(cox_bmi_meth$conf.int[2,1],3), 
				 signif(cox_bmi_pgrs$conf.int[2,1],3))
bmi_mat[2,] <- c(paste0(signif(cox_bmi$conf.int[2,3],3), " - ", signif(cox_bmi$conf.int[2,4],3)),
                 paste0(signif(cox_bmi_meth$conf.int[2,3],3), " - ", signif(cox_bmi_meth$conf.int[2,4],3)),
				 paste0(signif(cox_bmi_pgrs$conf.int[2,3],3), " - ", signif(cox_bmi_pgrs$conf.int[2,4],3)))
bmi_mat[3,] <- c(signif(cox_bmi$coef[2,5],2), 
                 signif(cox_bmi_meth$coef[2,5],2), 
				 signif(cox_bmi_pgrs$coef[2,5],2))
write.table(bmi_mat, file="BMI Cox stats_updated_survival.xls", sep='\t', quote=F, col.names=NA)

smk_mat[1,] <- c(signif(cox_smk$conf.int[2,1],3), 
                 signif(cox_smk$conf.int[3,1],3), 
                 signif(cox_smk_meth$conf.int[2,1],3), 
				 signif(cox_smk_pgrs$conf.int[2,1],3))
smk_mat[2,] <- c(paste0(signif(cox_smk$conf.int[2,3],3), " - ", signif(cox_smk$conf.int[2,4],3)),
                 paste0(signif(cox_smk$conf.int[3,3],3), " - ", signif(cox_smk$conf.int[3,4],3)),
                 paste0(signif(cox_smk_meth$conf.int[2,3],3), " - ", signif(cox_smk_meth$conf.int[2,4],3)),
				 paste0(signif(cox_smk_pgrs$conf.int[2,3],3), " - ", signif(cox_smk_pgrs$conf.int[2,4],3)))
smk_mat[3,] <- c(signif(cox_smk$coef[2,5],2), 
                        signif(cox_smk$coef[3,5],2), 
                        signif(cox_smk_meth$coef[2,5],2), 
				        signif(cox_smk_pgrs$coef[2,5],2))
write.table(smk_mat, file="Smoking Cox stats__updated_survival.xls", sep='\t', quote=F, col.names=NA)

# smk_mat_current[1,] <- c(signif(cox_smk$conf.int[3,1],3), 
#                  signif(cox_smk_meth$conf.int[2,1],3), 
#				 signif(cox_smk_pgrs$conf.int[2,1],3))
#smk_mat_current[2,] <- c(paste0(signif(cox_smk$conf.int[3,3],3), " - ", signif(cox_smk$conf.int[3,4],3)),
#                 paste0(signif(cox_smk_meth$conf.int[2,3],3), " - ", signif(cox_smk_meth$conf.int[3,4],3)),
# paste0(signif(cox_smk_pgrs$conf.int[2,3],3), " - ", signif(cox_smk_pgrs$conf.int[3,4],3)))
# smk_mat_current[3,] <- c(signif(cox_smk$coef[3,5],2), 
#                  signif(cox_smk_meth$coef[2,5],2), 
# 				 signif(cox_smk_pgrs$coef[2,5],2))
# write.table(smk_mat_current, file="Smoking Cox stats_current_updated_survival.xls", sep='\t', quote=F, col.names=NA)

alc_mat[1,] <- c(signif(cox_alc$conf.int[2,1],3), 
                 signif(cox_alc_meth$conf.int[2,1],3), 
				 signif(cox_alc_pgrs$conf.int[2,1],3))
alc_mat[2,] <- c(paste0(signif(cox_alc$conf.int[2,3],3), " - ", signif(cox_alc$conf.int[2,4],3)),
                 paste0(signif(cox_alc_meth$conf.int[2,3],3), " - ", signif(cox_alc_meth$conf.int[2,4],3)),
				 paste0(signif(cox_alc_pgrs$conf.int[2,3],3), " - ", signif(cox_alc_pgrs$conf.int[2,4],3)))
alc_mat[3,] <- c(signif(cox_alc$coef[2,5],2), 
                 signif(cox_alc_meth$coef[2,5],2), 
				 signif(cox_alc_pgrs$coef[2,5],2))			
write.table(alc_mat, file="Alcohol Cox stats_updated_survival.xls", sep='\t', quote=F, col.names=NA)

ea_mat[1,] <- c(signif(cox_ea$conf.int[2,1],3), 
                 signif(cox_ea_meth$conf.int[2,1],3), 
				 signif(cox_ea_pgrs$conf.int[2,1],3))
ea_mat[2,] <- c(paste0(signif(cox_ea$conf.int[2,3],3), " - ", signif(cox_ea$conf.int[2,4],3)),
                 paste0(signif(cox_ea_meth$conf.int[2,3],3), " - ", signif(cox_ea_meth$conf.int[2,4],3)),
				 paste0(signif(cox_ea_pgrs$conf.int[2,3],3), " - ", signif(cox_ea_pgrs$conf.int[2,4],3)))
ea_mat[3,] <- c(signif(cox_ea$coef[2,5],2), 
                 signif(cox_ea_meth$coef[2,5],2), 
				 signif(cox_ea_pgrs$coef[2,5],2))						 
write.table(ea_mat, file="Education Cox stats_updated_survival.xls", sep='\t', quote=F, col.names=NA)

#Forest plots
forestmat <- matrix(ncol=3)
colnames(forestmat) <- c("HR", "lowerCI", "upperCI")
models <- c("cox_bmi", "cox_bmi_meth", "cox_bmi_pgrs",# "cox_bmi_pgrs_meth", 
           "cox_alc", "cox_alc_meth", "cox_alc_pgrs", #"cox_alc_pgrs_meth",
		   "cox_smk", "cox_smk_meth", "cox_smk_pgrs", #"cox_smk_pgrs_meth",
		   "cox_ea", "cox_ea_meth", "cox_ea_pgrs")#, "cox_ea_pgrs_meth")
		   
for(i in models) {
    if(i == "cox_smk") {
	    forestmat <- rbind(forestmat, get(i)$conf.int[2,c(1,3,4)])# former smoker 
		forestmat <- rbind(forestmat, get(i)$conf.int[3,c(1,3,4)]) # current smoker
	    } else {
		  forestmat <- rbind(forestmat, get(i)$conf.int[2,c(1,3,4)])
	}
}
forestmat <- forestmat[-1,]
forestmat <- rbind(forestmat[1:11,], c("","",""), forestmat[12:13,])
rownames(forestmat)[c(1:11,13:14)] <- models
forest_plot <- data.frame(forestmat)
forest_plot$Phenotype <- factor(c(rep("BMI",3),
                           rep("Alcohol", 3),
						   rep("Smoking", 4),
						   rep("Education", 4)),
						 levels=rev(c("BMI", "Alcohol", "Smoking", "Education")))
forest_plot$Trait <- factor(c(rep(c("Phenotypic", "DNAm", "Polygenic"), 2),
                            c("Phenotypic (Former)", "Phenotypic (Current)", 
                              "DNAm", "Polygenic"),
                            c("Phenotypic", "", "DNAm", "Polygenic")), 
                            levels=c("Polygenic", "DNAm", "Phenotypic (Former)", 
							         "Phenotypic (Current)", "", "Phenotypic"))
   
forest_plot[,1:3] <- apply(forest_plot[,1:3], 2, function(x){signif(as.numeric(x), 3)})
   
					
for(i in c("BMI", "Alcohol", "Smoking", "Education")) {
assign(paste0("fp_", gsub(" |\\(|\\)", "_", i)), 
       ggplot(data=forest_plot[which(forest_plot$Phenotype==i), ], 
             aes(x=factor(Trait), y=HR, 
			 ymin=lowerCI, ymax=upperCI)) +
        geom_pointrange() + 
        geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        coord_flip() +  # flip coordinates (puts labels on y axis)
        xlab(" ") + 
	    ylab("HR (95% CI)") +
        theme_bw() + 
		ggtitle(paste(i)) + 
        theme(plot.title = element_text(hjust = 0.5)))  # use a white background

print(pdf(paste0("Forest_plot_", gsub(" |\\(|\\)", "_", i), "_updatedsurvival.pdf")))
print(get(paste0("fp_", gsub(" |\\(|\\)", "_", i))))
print(dev.off())
}

pdf("ForestPlots_MultiFig_updatedsurvival.pdf", width=9, height=9)
plot_grid(fp_BMI, fp_Alcohol, fp_Smoking, fp_Education,
         # labels = c("BMI", ,"Smoking", "Alcohol", "Education"),
          ncol = 2, align="hv")
dev.off()		  

pg$obese = ifelse(pg$bmi>30 & !is.na(pg$bmi),1, 
			ifelse(pg$bmi<=30 & !is.na(pg$bmi),0, NA))
pg$drinker = ifelse(pg$alc>21 & !is.na(pg$alc) & pg$sex == "M",1,
			ifelse(pg$alc<=21 & !is.na(pg$alc) & pg$sex == "M",0, NA))
pg$drinker[which(pg$sex=="F" & pg$alc >14)] <- 1
pg$drinker[which(pg$sex=="F" & pg$alc <=14)] <- 0

pg$smk_current_never <- pg$smk
pg$smk_current_never[pg$smk_current_never==1] <- NA
pg$smk_current_never[pg$smk_current_never==2] <- 1

pg$college = ifelse(pg$EA>11 & !is.na(pg$EA),1,
			ifelse(pg$EA<=11 & !is.na(pg$EA),0,NA))

pdf("ROC curves of univariate models (methylation).pdf")
plot(roc(obese ~ predicted_bmi , data=pg), main="AUCs")
plot(roc(drinker ~ predicted_alc , data=pg), add=T, col="red")
plot(roc(smk_current_never ~ predicted_smk , data=pg), add=T, col="blue")
plot(roc(college ~ predicted_ea , data=pg), add=T, col="darkgreen")
# Extract AUCS programatically in case of errors
legend("bottomright", c(paste("Current smoker: AUC = ",
       paste(signif(as.numeric(roc(smk_current_never ~ predicted_smk , data=pg)$auc),2))), 
	   paste("Heavy drinker: AUC = ", 
	   paste(signif(as.numeric(roc(drinker ~ predicted_alc , data=pg)$auc),2))), 
	   paste("Obese: AUC = ",
	   paste(signif(as.numeric(roc(obese ~ predicted_bmi , data=pg)$auc),2))),
	   paste("College Educated: AUC = ",
	   paste(signif(as.numeric(roc(college ~ predicted_ea , data=pg)$auc),2)))), 
	   bty="n", text.col=c("blue","red","black","darkgreen"))
	   dev.off()
	   
# Use ggplot for prettier ROC curves
smk <- pg[,c("smk_current_never", "predicted_smk")]
smk$Phenotype = paste0("Current Smoker (AUC = ", 
signif(as.numeric(roc(smk_current_never ~ predicted_smk, data=pg)$auc),2),
")")
smk$Colour <- brewer.pal(9, "Paired")[1]

bmi <- pg[,c("obese", "predicted_bmi")]
bmi$Phenotype = paste0("Obese (AUC = ", 
signif(as.numeric(roc(obese ~ predicted_bmi, data=pg)$auc),2),
")")
bmi$Colour <- brewer.pal(9, "Paired")[3]

alc <- pg[,c("drinker", "predicted_alc")]
alc$Phenotype = paste0("Moderate-to-Heavy Drinker (AUC = ", 
signif(as.numeric(roc(drinker ~ predicted_alc, data=pg)$auc),2),
")")
alc$Colour <- brewer.pal(9, "Paired")[7]

ea <- pg[,c("college", "predicted_ea")]
ea$Phenotype = paste0("College Educated (AUC = ", 
signif(as.numeric(roc(college ~ predicted_ea, data=pg)$auc),2),
")")
ea$Colour <- brewer.pal(9, "Paired")[9]
names(smk)[1:2] <- names(bmi)[1:2] <- names(alc)[1:2] <- names(ea)[1:2] <- c("Class", "Score")

new_roc <- rbind(smk, bmi, alc, ea)

# Reorder so highest auc is first factor level
factorlevs <- levels(factor(new_roc$Phenotype))
new_roc$Phenotype <- as.factor(new_roc$Phenotype) 
new_roc$Phenotype <- factor(new_roc$Phenotype, 
levels=c(factorlevs[2], factorlevs[3], factorlevs[4], factorlevs[1]))

#Conf intervals
alc_ci <- roc(drinker~predicted_alc, data=pg, ci=T)$ci
smk_ci <- roc(smk_current_never~predicted_smk, data=pg, ci=T)$ci
ea_ci <- roc(college~predicted_ea, data=pg, ci=T)$ci
bmi_ci <- roc(obese~predicted_bmi, data=pg, ci=T)$ci



pdf("AUCS_ggplot.pdf")
ggplot(new_roc, aes(d=Class, m=Score, color=Phenotype)) + 
geom_roc(n.cuts=0) + 
xlab("False Positive Rate (1 - Specificity)") +
ylab("True Positive Rate (Sensitivity)") + 
theme_gray() + 
ggtitle("AUCS") + 
theme(plot.title = element_text(hjust = 0.5)) +
theme(legend.position = c(0.7, 0.2))+ 
scale_colour_manual(values = brewer.pal(9, "Paired")[c(2,4,7,9)],
                       guide = guide_legend(override.aes = list(
                         linetype =rep("solid", 4)))) + 
geom_abline(slope=1,intercept=0, color="black")
dev.off()


# Paper presents AUCs for models suffixed with 2 (not fitting age/sex)

GLM_obese <- glm(obese ~ predicted_bmi + age + sex, data=pg, family=binomial(logit))
GLM_obese2 <- glm(obese ~ predicted_bmi + scale(bmi_pgrs), data=pg, family=binomial(logit))

GLM_drinker <- glm(drinker ~ predicted_alc  + age + sex, data=pg, family=binomial(logit))
GLM_drinker2 <- glm(drinker ~ predicted_alc + scale(alc_pgrs), data=pg, family=binomial(logit))

GLM_smoker <- glm(smk_current_never ~ predicted_smk  + age + sex, data=pg, family=binomial(logit))
GLM_smoker2 <- glm(smk_current_never ~ predicted_smk + scale(smk_pgrs), data=pg, family=binomial(logit))

GLM_college <- glm(college ~ predicted_ea  + age + sex, data=pg, family=binomial(logit))
GLM_college2 <- glm(college ~ predicted_ea + scale(ea_pgrs), data=pg, family=binomial(logit))


# Final sentence of AUC section in paper:
summary(glm(obese ~ predicted_bmi + bmi_pgrs + predicted_smk, data=pg, family=binomial(logit)))
summary(glm(drinker ~ predicted_alc + alc_pgrs + predicted_smk, data=pg, family=binomial(logit)))
summary(glm(college ~ predicted_ea + ea_pgrs + predicted_smk, data=pg, family=binomial(logit)))


# plot(roc(GLM_obese$y , GLM_obese$fitted.values))
# plot(roc(GLM_drinker$y , GLM_drinker$fitted.values), add=T, col="red")
# plot(roc(GLM_smoker$y , GLM_smoker$fitted.values), add=T, col="blue")

pdf("ROC curves of multivariate models (pheno + methylation + age + sex).pdf")
plot(roc(GLM_obese2$y , GLM_obese2$fitted.values))
plot(roc(GLM_drinker2$y , GLM_drinker2$fitted.values), add=T, col="red")
plot(roc(GLM_smoker2$y , GLM_smoker2$fitted.values), add=T, col="blue")
plot(roc(GLM_college2$y , GLM_college2$fitted.values), add=T, col="darkgreen")

# Extract AUCS programatically in case of errors
legend("bottomright", c(paste("Current smoker: AUC = ",
       paste(signif(as.numeric(roc(GLM_smoker2$y , GLM_smoker2$fitted.values)$auc),2))), 
	   paste("Moderate-to-heavy drinker: AUC = ", 
	   paste(signif(as.numeric(roc(GLM_drinker2$y , GLM_drinker2$fitted.values)$auc),2))), 
	   paste("Obese: AUC = ",
	   paste(signif(as.numeric(roc(GLM_obese2$y , GLM_obese2$fitted.values)$auc),2))),
	   paste("College educated: AUC = ",
	   paste(signif(as.numeric(roc(GLM_college2$y , GLM_college2$fitted.values)$auc),2)))),
	   bty="n", text.col=c("blue","red","black","darkgreen"))
dev.off()

pdf("ROC curves of multivariate models (methylation + age + sex).pdf")
plot(roc(GLM_obese$y , GLM_obese$fitted.values))
plot(roc(GLM_drinker$y , GLM_drinker$fitted.values), add=T, col="red")
plot(roc(GLM_smoker$y , GLM_smoker$fitted.values), add=T, col="blue")
plot(roc(GLM_college$y , GLM_college$fitted.values), add=T, col="darkgreen")
# Extract AUCS programatically in case of errors
legend("bottomright", c(paste("Current smoker: AUC = ",
       paste(signif(as.numeric(roc(GLM_smoker$y , GLM_smoker$fitted.values)$auc),2))), 
	   paste("Moderate-to-heavy drinker: AUC = ", 
	   paste(signif(as.numeric(roc(GLM_drinker$y , GLM_drinker$fitted.values)$auc),2))), 
	   paste("Obese: AUC = ",
	   paste(signif(as.numeric(roc(GLM_obese$y , GLM_obese$fitted.values)$auc),2))),
	   paste("College educated: AUC = ",
	   paste(signif(as.numeric(roc(GLM_college$y , GLM_college$fitted.values)$auc),2)))),
	   bty="n", text.col=c("blue","red","black","darkgreen"))
dev.off()

# Plot correlation matrix (lower diagonal=epigenetic score, upper diagonal=phenotypic score)
phenocor <- cor(pg[,c("bmi", "smk", "alc", "EA")], 
                use="pairwise.complete.obs")
epicor <- cor(pg[,c("predicted_bmi", "predicted_smk", "predicted_alc", "predicted_ea")], 
              use="pairwise.complete.obs")
			  
mixed_cor <- matrix(nrow=4, ncol=4)
colnames(mixed_cor) <- rownames(mixed_cor) <- c("BMI", "Smoking", "Alcohol", "Education")
for(i in 1:4) {
    if(rownames(mixed_cor)[i] == colnames(mixed_cor)[i]) { 
	    mixed_cor[i,i] <- "-"
		}
	}
mixed_cor[1,2:4] <- signif(phenocor[1,2:4],2)
mixed_cor[2,3:4] <- signif(phenocor[2,3:4],2)
mixed_cor[3,4] <- signif(phenocor[3,4],2)
mixed_cor[2:4,1] <- signif(epicor[2:4,1],2)
mixed_cor[3:4,2] <- signif(epicor[3:4,2],2)
mixed_cor[4,3] <- signif(epicor[4,3],2)
mixed_cor <- as.data.frame(mixed_cor)
write.table(mixed_cor, file="CorrelationMatrix_LowerEpi_UpperPheno_4x4.xls", sep='\t', 
            col.names=NA, quote=F)
			
allcor <- cor(pg[,c("bmi", "smk", "alc", "EA", 
                    "predicted_bmi", "predicted_smk", "predicted_alc", "predicted_ea")],
				use="pairwise.complete.obs")
rownames(allcor) <- colnames(allcor) <- 
c("BMI", "Smoking", "Alcohol", "Education", "Predicted BMI", 
  "Predicted Smoking", "Predicted Alcohol", "Predicted Education")
allcor <- apply(allcor, 2, function(x){signif(x,2)})
write.table(allcor, file="CorrelationMatrix_PhenoEpi_8x8.xls", sep='\t', 
            col.names=NA, quote=F)
			
			
			
hm_plot <- mixed_cor
hm_plot[1,1] <- hm_plot[2,2] <- hm_plot[3,3] <- hm_plot[4,4] <- NA
hm_plot <- apply(hm_plot, 2, as.numeric)
rownames(hm_plot) <- colnames(hm_plot)
pdf("CorrelationMatrix_HeatmapLowerEpi_UpperPheno_4x4.pdf")
heatmap.2(hm_plot, Rowv=NULL, Colv=NULL, 
          col=colorRampPalette(c("blue","white","red"))(256), 
		  dendrogram="none", tracecol=F, key=F, cellnote=hm_plot, 
		  notecol="black", cexRow=0.5, cexCol=0.5)
		  # Optional: separate tiles
		  #colsep=1:4, rowsep=1:4, sepcolor="black")
dev.off()


hm_plot <- allcor
hm_plot <- apply(hm_plot, 2, function(x){signif(x,2)})
rownames(hm_plot) <- colnames(hm_plot)
pdf("CorrelationMatrix_Heatmap_PhenoEpi_8x8.pdf")
heatmap.2(hm_plot, Rowv=NULL, Colv=NULL, 
          col=colorRampPalette(c("blue","white","red"))(256), 
		  dendrogram="none", tracecol=F, key=F, cellnote=hm_plot, 
		  notecol="black")#, cexRow=0.5, cexCol=0.5)
		  # Optional: separate tiles
		  #colsep=1:4, rowsep=1:4, sepcolor="black")
dev.off()


# Correct for WBC counts and technical factors
wbc <- read.table("LBC1921_w1_w5_LBC1936_w1_w4_DNAmAge_11Sep2017.txt", 
                  sep='\t', header=T)
wbc <- wbc[which(wbc$ID %in% pg$ID & wbc$WAVE==1),]
pg <- merge(pg, wbc[,c("ID", "date", "array", "pos", "plate", 
                    "neut", "lymph", "mono", "eosin", "baso")], 
                    by.y="ID", all=F) %>% droplevels
                    
cox_bmi_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi) +
                        # # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_alc_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc) +
                        # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_smk_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + factor(smk) +
                       #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_ea_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(EA) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))

cox_bmi_meth_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_bmi) +
                        # # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_alc_meth_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_alc) +
                        # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_smk_meth_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_smk) +
                       #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_ea_meth_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(predicted_ea) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))

cox_bmi_pg_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi_pgrs) +
                        # # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_alc_pg_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc_pgrs) +
                        # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_smk_pg_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(smk_pgrs) +
                       #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_ea_pg_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(ea_pgrs) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
                        

cox_bmi_cond_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi) + scale(predicted_bmi) +
                        # # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_alc_cond_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc) + scale(predicted_alc) +
                        # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_smk_cond_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + factor(smk) + scale(predicted_smk) +
                       #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))
cox_ea_cond_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(EA) + scale(predicted_ea) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        neut + lymph + mono + eosin + baso, data=pg))

cox_bmi_cond_smk_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(bmi) + scale(predicted_bmi) +
                        # # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_alc_cond_smk_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(alc) + scale(predicted_alc) +
                        # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_ea_cond_smk_supp <- summary(coxph(Surv(age, age_event, event) ~ sex + scale(EA) + scale(predicted_ea) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))

supp_pheno <- matrix(ncol=3, nrow=5)
supp_pgrs <- matrix(ncol=3, nrow=4)
supp_meth <- matrix(ncol=3, nrow=4)
supp_cond_meth <- matrix(ncol=3, nrow=9)
supp_cond_meth_smk <- matrix(ncol=3, nrow=9)

colnames(supp_pheno) <- colnames(supp_pgrs) <- colnames(supp_meth) <- 
colnames(supp_cond_meth) <- colnames(supp_cond_meth_smk) <-
c("HR", "95% CI", "P")

rownames(supp_pheno) <- c("BMI", "Former smoker", "Current smoker", "Alcohol", "Education")
rownames(supp_pgrs) <- rownames(supp_meth) <- c("BMI", "Smoking", "Alcohol", "Education")

rownames(supp_cond_meth) <- c("Phenotypic BMI", "DNAm BMI", 
                              "Phenotypic smoking (Former)", "Phenotypic smoking (Current)",
                              "DNAm Smoking",
                              "Phenotypic Alcohol", "DNAm Alcohol",
                              "Phenotypic Education", "DNAm Education")
                              
rownames(supp_cond_meth_smk) <- c("Phenotypic BMI", "DNAm BMI", "DNAm Smoking BMI",
                              "Phenotypic Alcohol", "DNAm Alcohol", "DNAm Smoking Alcohol",
                              "Phenotypic Education", "DNAm Education", "DNAm Smoking Education")
supp_pheno[1,1] <- cox_bmi_supp$conf[2,1]
supp_pheno[1,2] <- paste0(cox_bmi_supp$conf[2,3], " - ", cox_bmi_supp$conf[2,4])
supp_pheno[1,3] <- cox_bmi_supp$coef[2,5]
supp_pheno[2,1] <- cox_smk_supp$conf[2,1]
supp_pheno[2,2] <- paste0(cox_smk_supp$conf[2,3], " - ", cox_smk_supp$conf[2,4])
supp_pheno[2,3] <- cox_smk_supp$coef[2,5]
supp_pheno[3,1] <- cox_smk_supp$conf[3,1]
supp_pheno[3,2] <- paste0(cox_smk_supp$conf[3,3], " - ", cox_smk_supp$conf[3,4])
supp_pheno[3,3] <- cox_smk_supp$coef[3,5]
supp_pheno[4,1] <- cox_alc_supp$conf[2,1]
supp_pheno[4,2] <- paste0(cox_alc_supp$conf[2,3], " - ", cox_alc_supp$conf[2,4])
supp_pheno[4,3] <- cox_alc_supp$coef[2,5]
supp_pheno[5,1] <- cox_ea_supp$conf[2,1]
supp_pheno[5,2] <- paste0(cox_ea_supp$conf[2,3], " - ", cox_ea_supp$conf[2,4])
supp_pheno[5,3] <- cox_ea_supp$coef[2,5]

supp_pgrs[1,1] <- cox_bmi_pg_supp$conf[2,1]
supp_pgrs[1,2] <- paste0(cox_bmi_pg_supp$conf[2,3], " - ", cox_bmi_pg_supp$conf[2,4])
supp_pgrs[1,3] <- cox_bmi_pg_supp$coef[2,5]
supp_pgrs[2,1] <- cox_smk_pg_supp$conf[2,1]
supp_pgrs[2,2] <- paste0(cox_smk_pg_supp$conf[2,3], " - ", cox_smk_pg_supp$conf[2,4])
supp_pgrs[2,3] <- cox_smk_pg_supp$coef[2,5]
supp_pgrs[3,1] <- cox_alc_pg_supp$conf[2,1]
supp_pgrs[3,2] <- paste0(cox_alc_pg_supp$conf[2,3], " - ", cox_alc_pg_supp$conf[2,4])
supp_pgrs[3,3] <- cox_alc_pg_supp$coef[2,5]
supp_pgrs[4,1] <- cox_ea_pg_supp$conf[2,1]
supp_pgrs[4,2] <- paste0(cox_ea_pg_supp$conf[2,3], " - ", cox_ea_pg_supp$conf[2,4])
supp_pgrs[4,3] <- cox_ea_pg_supp$coef[2,5]

supp_meth[1,1] <- cox_bmi_meth_supp$conf[2,1]
supp_meth[1,2] <- paste0(cox_bmi_meth_supp$conf[2,3], " - ", cox_bmi_meth_supp$conf[2,4])
supp_meth[1,3] <- cox_bmi_meth_supp$coef[2,5]
supp_meth[2,1] <- cox_smk_meth_supp$conf[2,1]
supp_meth[2,2] <- paste0(cox_smk_meth_supp$conf[2,3], " - ", cox_smk_meth_supp$conf[2,4])
supp_meth[2,3] <- cox_smk_meth_supp$coef[2,5]
supp_meth[3,1] <- cox_alc_meth_supp$conf[2,1]
supp_meth[3,2] <- paste0(cox_alc_meth_supp$conf[2,3], " - ", cox_alc_meth_supp$conf[2,4])
supp_meth[3,3] <- cox_alc_meth_supp$coef[2,5]
supp_meth[4,1] <- cox_ea_meth_supp$conf[2,1]
supp_meth[4,2] <- paste0(cox_ea_meth_supp$conf[2,3], " - ", cox_ea_meth_supp$conf[2,4])
supp_meth[4,3] <- cox_ea_meth_supp$coef[2,5]

supp_cond_meth[1:2,1] <- cox_bmi_cond_supp$conf[2:3,1]
supp_cond_meth[1:2,2] <- paste0(cox_bmi_cond_supp$conf[2:3,3], " - ", cox_bmi_cond_supp$conf[2:3,4])
supp_cond_meth[1:2,3] <- cox_bmi_cond_supp$coef[2:3,5]
supp_cond_meth[3:5,1] <- cox_smk_cond_supp$conf[2:4,1]
supp_cond_meth[3:5,2] <- paste0(cox_smk_cond_supp$conf[2:4,3], " - ", cox_smk_cond_supp$conf[2:4,4])
supp_cond_meth[3:5,3] <- cox_smk_cond_supp$coef[2:4,5]
supp_cond_meth[6:7,1] <- cox_alc_cond_supp$conf[2:3,1]
supp_cond_meth[6:7,2] <- paste0(cox_alc_cond_supp$conf[2:3,3], " - ", cox_alc_cond_supp$conf[2:3,4])
supp_cond_meth[6:7,3] <- cox_alc_cond_supp$coef[2:3,5]
supp_cond_meth[8:9,1] <- cox_ea_cond_supp$conf[2:3,1]
supp_cond_meth[8:9,2] <- paste0(cox_ea_cond_supp$conf[2:3,3], " - ", cox_ea_cond_supp$conf[2:3,4])
supp_cond_meth[8:9,3] <- cox_ea_cond_supp$coef[2:3,5]

supp_cond_meth_smk[1:3,1] <- cox_bmi_cond_smk_supp$conf[2:4,1]
supp_cond_meth_smk[1:3,2] <- paste0(cox_bmi_cond_smk_supp$conf[2:4,3], " - ", cox_bmi_cond_smk_supp$conf[2:4,4])
supp_cond_meth_smk[1:3,3] <- cox_bmi_cond_smk_supp$coef[2:4,5]
supp_cond_meth_smk[4:6,1] <- cox_alc_cond_smk_supp$conf[2:4,1]
supp_cond_meth_smk[4:6,2] <- paste0(cox_alc_cond_smk_supp$conf[2:4,3], " - ", cox_alc_cond_smk_supp$conf[2:4,4])
supp_cond_meth_smk[4:6,3] <- cox_alc_cond_smk_supp$coef[2:4,5]
supp_cond_meth_smk[7:9,1] <- cox_ea_cond_smk_supp$conf[2:4,1]
supp_cond_meth_smk[7:9,2] <- paste0(cox_ea_cond_smk_supp$conf[2:4,3], " - ", cox_ea_cond_smk_supp$conf[2:4,4])
supp_cond_meth_smk[7:9,3] <- cox_ea_cond_smk_supp$coef[2:4,5]

write.table(supp_pheno, file="Phenotypic_cox_celladj.xls", sep='\t', quote=F, col.names=NA)
write.table(supp_pgrs, file="PGRS_cox_celladj.xls", sep='\t', quote=F, col.names=NA)
write.table(supp_meth, file="DNAm_cox_celladj.xls", sep='\t', quote=F, col.names=NA)
write.table(supp_cond_meth, file="Pheno_Meth_cox_celladj.xls", sep='\t', quote=F, col.names=NA)
write.table(supp_cond_meth_smk, file="Pheno_Meth_Smk_cox_celladj.xls", sep='\t', quote=F, col.names=NA)

save.image("Models_Figures_and_Tables_for_Paper.RData")

# Qian Zhang: correlation between GS variables?
gs_cor <- cor(d4[,c("bmi","pack_years","units","years")], use="pairwise.complete.obs")
rownames(gs_cor) <- colnames(gs_cor) <- c("BMI", "Smoking", "Alcohol", "Education")
write.table(gs_cor, file="correlation_gs_variables.xls", sep='\t', quote=F, col.names=NA)

# Potential additional figure:
# Smoking groups and scores (boxplot)
pg2 <- pg 
levels(factor(pg2$smk))
# [1] "0" "1" "2"
pg2$smk <- gsub("0", "Never smoker", pg2$smk)
pg2$smk <- gsub("1", "Former smoker", pg2$smk)
pg2$smk <- gsub("2", "Current smoker", pg2$smk)

pg2$smk <- factor(pg2$smk, levels=c("Never smoker" ,"Former smoker", "Current smoker"))

pdf("Smoking_boxplots.pdf")
ggplot(pg2, aes(factor(smk), y=scale(predicted_smk))) + 
scale_x_discrete(labels=c("Never smoker" ,"Former smoker", "Current smoker")) +
geom_boxplot(aes(fill=factor(smk))) + 
scale_color_manual(values = c("black", "black", "black")) + 
       xlab("Phenotypic Smoking") + 
	    ylab("DNAm smoking scores") +
		guides(fill=FALSE) + 
		# ggtitle(paste("DNAm Smoking score by phenotypic smoking group")) + 
		# theme(plot.title = element_text(hjust = 0.5)) + 
		theme_gray()
dev.off()

formernever <- pg2[which(pg2$smk %in% c("Never smoker", "Former smoker")),c("smk","predicted_smk")] %>% droplevels
currentnever <- pg2[which(pg2$smk %in% c("Never smoker", "Current smoker")),c("smk","predicted_smk")] %>% droplevels
formercurrent <- pg2[which(pg2$smk %in% c("Former smoker", "Current smoker")),c("smk","predicted_smk")] %>% droplevels

t.test(scale(pg$pre)
