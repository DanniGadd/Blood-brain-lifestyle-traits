load("M:/lasso_prediction/Alc_LASSO_coefficients_25Jan2018.RData")
coef_alc <- coef
load("M:/lasso_prediction/EA_LASSO_coefficients_08Feb2018.RData")
coef_ea <- coef
load("M:/lasso_prediction/Smk_LASSO_coefficients_25Jan2018.RData")
coef_smk <- coef
load("M:/lasso_prediction/BMI_LASSO_coefficients_25Jan2018.RData")
coef_bmi <- coef

write.table(coef_bmi,file="M:/lasso_prediction/BMI_coefficients.xls", sep='\t', quote=F, row.names=F)
write.table(coef_alc,file="M:/lasso_prediction/Alc_coefficients.xls", sep='\t', quote=F, row.names=F)
write.table(coef_smk,file="M:/lasso_prediction/Smk_coefficients.xls", sep='\t', quote=F, row.names=F)
write.table(coef_ea,file="M:/lasso_prediction/EA_coefficients.xls", sep='\t', 