cox_bmi_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(bmi) + scale(predicted_bmi) + scale(bmi_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))
                        
cox_smk_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + factor(smk) + scale(predicted_smk) + scale(smk_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_alc_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(alc) + scale(predicted_alc) + scale(alc_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_ea_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(EA) + scale(predicted_ea) + scale(ea_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))

cox_tc_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(tc) + scale(predicted_tc) + scale(tc_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_hdl_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(hdl) + scale(predicted_hdl) + scale(hdl_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))       

cox_ldl_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ldl) + scale(predicted_ldl) + scale(ldl_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        
                        
cox_ratio_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ratio) + scale(predicted_ratio) +
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        

cox_whr_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_whr) + scale(whr_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                                  

cox_fat_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_fat) + scale(bodyfat_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))            

cox_bmi_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(bmi) +
                        neut + lymph + mono + eosin + baso, data=pg))
                        
cox_smk_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + factor(smk) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_alc_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(alc) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_ea_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(EA) + scale(predicted_ea) + scale(ea_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))

cox_tc_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(tc) + scale(predicted_tc) + scale(tc_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_hdl_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(hdl) + scale(predicted_hdl) + scale(hdl_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))       

cox_ldl_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ldl) + scale(predicted_ldl) + scale(ldl_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        
                        
cox_ratio_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ratio) + scale(predicted_ratio) +
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        

cox_whr_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_whr) + scale(whr_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                                  

cox_fat_pheno_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_fat) + scale(bodyfat_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                                    
                        

forestmat <- matrix(ncol=3)
colnames(forestmat) <- c("HR", "lowerCI", "upperCI")
models <- c("cox_bmi_fplot", "cox_alc_fplot", "cox_smk_fplot", 
            "cox_ea_fplot", "cox_tc_fplot", "cox_hdl_fplot", 
            "cox_ldl_fplot", "cox_ratio_fplot", "cox_whr_fplot", 
            "cox_fat_fplot")#, "cox_ea_pgrs_meth")
		   
for(i in models) {
print(i)
    if(i == "cox_smk_fplot") {
	    forestmat <- rbind(forestmat, 
                   get(i)$conf.int[3:6,c(1,3,4)])# former,current, dnam, pgrs
	    } 
    else if(i == "cox_whr_fplot") {
      forestmat <- rbind(forestmat, 
                         c("","",""), #pheno blank
                         c("","",""), #pheno blank
                         get(i)$conf.int[3:4,c(1,3,4)]) #dnam + pgrs
                         
      }
    else if(i == "cox_fat_fplot") {
      forestmat <- rbind(forestmat, 
                         c("","",""), #pheno blank
                         c("","",""), #pheno blank
                         get(i)$conf.int[3:4,c(1,3,4)]) #dnam + pgrs
      }       
    else if(i == "cox_ratio_fplot") { 
      forestmat <- rbind(forestmat, 
                         get(i)$conf.int[3,c(1,3,4)], #pheno
                         c("","",""), #pheno blank
                         get(i)$conf.int[4,c(1,3,4)],#dnam 
                         c("","","")) # pgrs blank)
    } else {
		  forestmat <- rbind(forestmat, 
      get(i)$conf.int[3,c(1,3,4)],
      c("","",""), # blank phenotype
      get(i)$conf.int[4:5,c(1,3,4)]) # dnam plus pgrs
	}
print(nrow(forestmat))
}
forestmat <- forestmat[-1,]
# forestmat <- rbind(forestmat[1:7,], c("","",""), forestmat[8:nrow(forestmat),]) # why did I do this?


forest_plot <- data.frame(forestmat)
forest_plot$Phenotype <- factor(c(rep("BMI",4),
                           rep("Alcohol", 4),
						   rep("Smoking", 4),
						   rep("Education", 4),
               rep("TC", 4),
               rep("HDL", 4),
               rep("LDL", 4),
               rep("TC_HDL_Ratio", 4),
               rep("WHR", 4),
               rep("Body_Fat", 4)),
						 levels=rev(c("BMI", "Alcohol", "Smoking", "Education", 
                          "TC", "HDL", "LDL", "TC_HDL_Ratio",
                          "WHR", "Body_Fat")))
  forest_plot$Trait <- factor(c(rep(c("Phenotypic", "", "DNAm", "Polygenic"), 2),
                              c("Phenotypic (Former)", "Phenotypic (Current)", 
                                "DNAm", "Polygenic"),
                              rep(c("Phenotypic", "", "DNAm", "Polygenic"),4),
                              c("Phenotypic", "", "DNAm", " "),
                              rep(c("", " ", "DNAm", "   "),2)),
                              levels=c(" ", "Polygenic", "DNAm" ,"", "   ", "Phenotypic (Current)", "Phenotypic (Former)", "Phenotypic"))
   
forest_plot[,1:3] <- apply(forest_plot[,1:3], 2, function(x){signif(as.numeric(x), 3)})
   
					
  for(i in c("BMI", "Alcohol", "Smoking", "Education", 
             "TC", "HDL", "LDL", "TC_HDL_Ratio", "WHR", "Body_Fat")) {
  assign(paste0("fp_", gsub(" |\\(|\\)", "_", i)), 
         ggplot(data=forest_plot[which(forest_plot$Phenotype==i), ], 
               aes(x=factor(Trait), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle(paste(i)) + 
          theme(plot.title = element_text(hjust = 0.5))) # use a white background
         
          

  print(pdf(paste0("Forest_plot_", gsub(" |\\(|\\)", "_", i), "_updatedsurvival.pdf")))
  print(get(paste0("fp_", gsub(" |\\(|\\)", "_", i))))
  print(dev.off())
  }

# Forest plot of DNAm only
         pdf("DNAm_scores_only.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait=="DNAm"), ]
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=plot_tmp$Phenotype)
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("DNA Methylation Scores") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)

# Forest plot of PGRS only
         pdf("PGRS_only.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait=="Polygenic"), ]
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=plot_tmp$Phenotype)
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("Polygenic Risk Scores") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)
  

# Forest plot of Phenotypes only
         pdf("Phenotypes_only.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait%in%c("Phenotypic", "Phenotypic (Former)", "Phenotypic (Current)")), ]
         plot_tmp$Phenotype <- as.character(plot_tmp$Phenotype)
         plot_tmp[which(plot_tmp$Trait == "Phenotypic (Former)"),"Phenotype"] <- "Former Smoker"
         plot_tmp[which(plot_tmp$Trait == "Phenotypic (Current)"),"Phenotype"] <- "Current Smoker"
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=unique(plot_tmp$Phenotype))
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("Phenotypes") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)
  
  
pdf("ForestPlots_MultiFig_updatedsurvival.pdf", width=18, height=6)
plot_grid(fp_BMI, fp_Alcohol, fp_Smoking, fp_Education, fp_TC, 
          fp_HDL, fp_LDL, fp_TC_HDL_Ratio, fp_WHR, fp_Body_Fat,
         # labels = c("BMI", "Alcohol", "Smoking", "Education", "TC", "HDL", "LDL", "Ratio"),
          ncol = 5, align="hv")
dev.off()		  
                       


# For Bioinformatics talk
         pdf("DNAm_scores_4_traits.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait=="DNAm" & 
                                 forest_plot$Phenotype %in% c("BMI", "Smoking", "Alcohol", "Education")), ]
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=plot_tmp$Phenotype)
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("DNA Methylation Scores") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)
                       