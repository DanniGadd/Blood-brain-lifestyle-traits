setwd("Z:/Daniel/Forensic_methylation_Feb2018/post_review_models")
source("../functions.R")
library(ggplot2)
library(rms)
library(survival)
library(pROC)
library(reshape2)
library(dplyr)
library(RColorBrewer)
library(gplots)
library(MASS)
library(gridExtra)
library(ggpubr)
library(cowplot)
library(foreign)
library(plotROC)
library(XLConnect)
library(pheatmap)
library(coxme)

weights <- list()
weights[["alc"]] <- read.csv("Alcohol_Predictors.csv", sep=',', header=T)
weights[["bmi"]] <- read.csv("BMI_Predictors.csv", sep=',', header=T)
weights[["smk"]] <- read.csv("Smoking_Predictors.csv", sep=',', header=T)
weights[["EA"]] <- read.csv("Education_Predictors.csv", sep=',', header=T)
weights[["whr"]] <- read.csv("WHR_Predictors.csv", sep=',', header=T)
weights[["total"]] <- read.csv("Total_Chol_Predictors.csv", sep=',', header=T)
weights[["hdl"]] <- read.csv("HDL_Chol_Predictors.csv", sep=',', header=T)
weights[["ldl"]] <- read.csv("LDL_Remnant_Predictors.csv", sep=',', header=T)
weights[["ratio"]] <- read.csv("HDL_Ratio_Predictors.csv", sep=',', header=T)
weights[["fat"]] <- read.csv("Body_Fat_Predictors.csv", sep=',', header=T)

scores <- read.csv("LBC_Score_All_Predictors.csv", sep=',', header=T)

### Done on CCACE servers ###
### Check correlation between EA signature with and without smoking probe 
##############
# setwd("/Cluster_Filespace/Marioni_Group/Daniel")
# load("../LBC/LBC_methylation/Beta_3525_norm_bgcorrect_0.001BetaThreshold_probefilter.RObject")
# targets <- read.csv("../LBC/LBC_methylation/target_QC_age_sex_date.csv")
# targets <- targets[which(targets$cohort == "LBC36"),]
# targets <- targets[which(targets$WAVE == 1),]
# lbc_rm <- c("LBC360558", "LBC360760", "LBC360536", "LBC361272", "LBC360213",
            # "LBC360262", "LBC361264", "LBC361030", "LBC360412", "LBC361076", 
            # "LBC360721")
# targets <- targets[which(!targets$ID_raw %in% lbc_rm),]
# dat <- dat[,as.character(targets$Basename)]
# ea_coef <- read.csv("../Updated LASSOs/Predictors/Education_Predictors.csv" ,sep=',', header=T)
# probes <- intersect(ea_coef$CpG_Site, rownames(dat))
# rownames(ea_coef) <- ea_coef$CpG_Site
# b <- dat[probes, ]
# p <- ea_coef[probes,]

# for(i in probes) { 
  # b[i,] = b[i,] * p [i, "Beta"]
  # }
# ea_score1 <- colSums(b, na.rm=TRUE) 
 # probes2 <- probes[-which(!probes %in% c("cg11902777", "cg05575921"))]
# b <- dat[probes, ]
# p <- ea_coef[probes,]

# for(i in probes2) { 
  # b[i,] = b[i,] * p [i, "Beta"]
  # }
# ea_score2 <- colSums(b, na.rm=TRUE) 
# cor(ea_score1, ea_score2)
# [1] 0.9958636




# Load 'd4' object
load("../GS_descriptives_for_LASSO_15Feb2018.RData")
 gs_chol_vars <- read.csv("gs_cholesterol_vars_from_rob.csv", sep=',', header=T)
 gs_omit <- c(13645, 146241, 105326, 33449,20944, 29470,
             38665, 37889, 76209, 91587, 126765, 146022, 129642)
d4 <- d4[which(!d4$Sample_Name %in% gs_omit), ] 
d4 <- left_join(d4, gs_chol_vars[,1:12], by="Sample_Name")
fat_whr <- read.csv("Body_Fat_Residuals.csv", sep=',', header=T)
fat_whr <- fat_whr[which(fat_whr$Sample_Name %in% d4$Sample_Name), ]
d4 <- left_join(d4, fat_whr[,c("Sample_Name", "whr", "body_fat")], by="Sample_Name")

## Done on local machine
library(kinship2)

ped = read.csv("M:/Postdoc Background/GS_data/GS_data/clinical/pedigree.csv", header=T)

ped$father <- as.numeric(ped$father)
ped$mother <- as.numeric(ped$mother)

ped$father[ped$father==0] <- NA
ped$mother[ped$mother==0] <- NA

table(ped$sex)
ped$sex <- as.numeric(ped$sex)
ped$sex[ped$sex==2] <- 0
ped$sex <- ped$sex+1

kin <- with(ped, pedigree(volid, father, mother, sex, famid=famid))

a <- kinship(kin)

bmi = d4[!is.na(d4$bmi),]
bmi$bmi_res = resid(lm(log(bmi) ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=bmi)) 
bmi$bmi_res_2 = resid(lmekin(log(bmi) ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=bmi, varlist=2*a)) 
cor(bmi$bmi_res, bmi$bmi_res_2)
# [1] 0.9563526

alc = d4[!is.na(d4$units),]
alc$alc_res = resid(lm(log(units + 1) ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=alc)) 
alc$alc_res_2 = resid(lmekin(log(units + 1) ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=alc, varlist=2*a)) 
cor(alc$alc_res, alc$alc_res_2)
# [1] 0.9946907

smk = d4[!is.na(d4$pack_years),]
smk$smk_res = resid(lm(log(pack_years + 1) ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=smk)) 
smk$smk_res_2 = resid(lmekin(log(pack_years + 1) ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=smk, varlist=2*a)) 
cor(smk$smk_res, smk$smk_res_2)
# [1] 0.9805281

ea = d4[!is.na(d4$years),]
ea$ea_res = resid(lm(years ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=ea)) 
ea$ea_res_2 = resid(lmekin(years ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=ea, varlist=2*a)) 
cor(ea$ea_res, ea$ea_res_2)
# [1] 0.9665938

tc = d4[!is.na(d4$Total_cholesterol),]
tc$tc_res = resid(lm(Total_cholesterol ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=tc)) 
tc$tc_res_2 = resid(lmekin(Total_cholesterol ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=tc, varlist=2*a)) 
cor(tc$tc_res, tc$tc_res_2)
# [1] 0.9873299

hdl = d4[!is.na(d4$HDL_cholesterol),]
hdl$hdl_res = resid(lm(HDL_cholesterol ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=hdl)) 
hdl$hdl_res_2 = resid(lmekin(HDL_cholesterol ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=hdl, varlist=2*a)) 
cor(hdl$hdl_res, hdl$hdl_res_2)
# [1] 0.9662536

ldl = d4[!is.na(d4$LDL_with_Remnant_Cholesterol),]
ldl$ldl_res = resid(lm(LDL_with_Remnant_Cholesterol ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=ldl)) 
ldl$ldl_res_2 = resid(lmekin(LDL_with_Remnant_Cholesterol ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=ldl, varlist=2*a)) 
cor(ldl$ldl_res, ldl$ldl_res_2)
# [1] 0.9838742

ratio = d4[!is.na(d4$HDL_Ratio),]
ratio$ratio_res = resid(lm(HDL_Ratio ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=ratio)) 
ratio$ratio_res_2 = resid(lmekin(HDL_Ratio ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=ratio, varlist=2*a)) 
cor(ratio$ratio_res, ratio$ratio_res_2)
# [1] 0.9692178

whr = d4[!is.na(d4$whr),]
whr$whr_res = resid(lm(whr ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=whr)) 
whr$whr_res_2 = resid(lmekin(whr ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=whr, varlist=2*a)) 
cor(whr$whr_res, whr$whr_res_2)
# [1] 0.9863369

body_fat = d4[!is.na(d4$body_fat),]
body_fat$body_fat_res = resid(lm(body_fat ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10, data=body_fat)) 
body_fat$body_fat_res_2 = resid(lmekin(body_fat ~ Age + Female + PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + PC8 + PC9 + PC10 + (1|Sample_Name), data=body_fat, varlist=2*a)) 
cor(body_fat$body_fat_res, body_fat$body_fat_res_2)
# [1] 0.9635745


# Load 'pg' object
load("../Epi_signatures_of_death_15Feb2018.RData")
lbc_rm <- c("LBC360558", "LBC360760", "LBC360536", "LBC361272", "LBC360213",
            "LBC360262", "LBC361264", "LBC361030", "LBC360412", "LBC361076", 
            "LBC360721")
pg <- pg[which(!pg$ID %in% lbc_rm), ]

additional_phenos <-  read.csv("LBC_Phenotypic_Data.csv", sep=',', header=T)
pg$hdl <- additional_phenos[match(pg$ID, additional_phenos$lbc36no), "bld_hdlchol_w1"]
pg$tc <- additional_phenos[match(pg$ID, additional_phenos$lbc36no), "bld_choles_w1"]
pg$ratio <- additional_phenos[match(pg$ID, additional_phenos$lbc36no), "bld_hdlrat_w1"]
pg$ldl <- pg$tc - pg$hdl

hdl_pgrs <- read.table("HDL.all.score",header=T, check.names=F)
ldl_pgrs <- read.table("LDL.all.score",header=T, check.names=F)
tc_pgrs <- read.table("TC.all.score",header=T, check.names=F)
whr_pgrs <- read.table("whr.all.score",header=T, check.names=F)
bodyfat_pgrs <- read.table("bodyfat.all.score",header=T, check.names=F)

pg$hdl_pgrs <- hdl_pgrs[match(pg$ID, hdl_pgrs$IID), 7]
pg$ldl_pgrs <- ldl_pgrs[match(pg$ID, ldl_pgrs$IID), 7]
pg$tc_pgrs <- tc_pgrs[match(pg$ID, tc_pgrs$IID), 7]
pg$whr_pgrs <- whr_pgrs[match(pg$ID, whr_pgrs$IID), 7]
pg$bodyfat_pgrs <- bodyfat_pgrs[match(pg$ID, bodyfat_pgrs$IID), 7]

pg$predicted_bmi <- scores[match(pg$Basename, scores$Basename), "BMI_Score"]
pg$predicted_smk <- scores[match(pg$Basename, scores$Basename), "Smoking_Score"]
pg$predicted_alc <- scores[match(pg$Basename, scores$Basename), "Alcohol_Score"]
pg$predicted_ea <- scores[match(pg$Basename, scores$Basename), "Education_Score"]

pg$predicted_whr <- scores[match(pg$Basename, scores$Basename), "WHR_Score"]
pg$predicted_fat <- scores[match(pg$Basename, scores$Basename), "Body_Fat_Score"]
pg$predicted_hdl <- scores[match(pg$Basename, scores$Basename), "HDL_Chol_Score"]
pg$predicted_ldl <- scores[match(pg$Basename, scores$Basename), "LDL_Remnant_Score"]
pg$predicted_ratio <- scores[match(pg$Basename, scores$Basename), "HDL_Ratio_Score"]
pg$predicted_tc <- scores[match(pg$Basename, scores$Basename), "Total_Chol_Score"]


# BMI
m0 =  summary(lm(bmi ~ age + sex, data=pg))
m1 =  summary(lm(bmi ~ age + sex + scale(predicted_bmi) + scale(bmi_pgrs), data=pg))
m2 =  summary(lm(bmi ~ age + sex + scale(predicted_bmi), data=pg))
m3 =  summary(lm(bmi ~ age + sex + scale(bmi_pgrs), data=pg))
bmi_r_add <- 100*(m1$r.squared - m0$r.squared)
bmi_r_meth <- 100*(m2$r.squared - m0$r.squared)
bmi_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

# EA
m0 =  summary(lm(EA ~ age + sex, data=pg))
m1 =  summary(lm(EA ~ age + sex + scale(predicted_ea) + scale(ea_pgrs), data=pg))
m2 =  summary(lm(EA ~ age + sex + scale(predicted_ea), data=pg))
m3 =  summary(lm(EA ~ age + sex + scale(ea_pgrs), data=pg))
ea_r_add <- 100*(m1$r.squared - m0$r.squared)
ea_r_meth <- 100*(m2$r.squared - m0$r.squared)
ea_r_pgrs <- 100*(m3$r.squared - m0$r.squared)


# Smoking
m0 = orm(smk ~ age + sex, data=pg)
m1 = orm(smk ~ age + sex + scale(smk_pgrs) + scale(predicted_smk), data=pg)
m2 = orm(smk ~ age + sex + scale(predicted_smk), data=pg)
m3 = orm(smk ~ age + sex + scale(smk_pgrs), data=pg)
smk_r_add <- 100*(m1[["stats"]]["R2"] - m0[["stats"]]["R2"])
smk_r_meth <- 100*(m2[["stats"]]["R2"] - m0[["stats"]]["R2"])
smk_r_pgrs <- 100*(m3[["stats"]]["R2"] - m0[["stats"]]["R2"])


# Alcohol
m0 =  summary(lm(alc ~ age + sex, data=pg))
m1 =  summary(lm(alc ~ age + sex + scale(predicted_alc) + scale(alc_pgrs), data=pg))
m2 =  summary(lm(alc ~ age + sex + scale(predicted_alc), data=pg))
m3 =  summary(lm(alc ~ age + sex + scale(alc_pgrs), data=pg))
alc_r_add <- 100*(m1$r.squared - m0$r.squared)
alc_r_meth <- 100*(m2$r.squared - m0$r.squared)
alc_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

# Total cholesterol
m0 =  summary(lm(tc ~ age + sex, data=pg))
m1 =  summary(lm(tc ~ age + sex + scale(predicted_tc) + scale(tc_pgrs), data=pg))
m2 =  summary(lm(tc ~ age + sex + scale(predicted_tc), data=pg))
m3 =  summary(lm(tc ~ age + sex + scale(tc_pgrs), data=pg))
tc_r_add <- 100*(m1$r.squared - m0$r.squared)
tc_r_meth <- 100*(m2$r.squared - m0$r.squared)
tc_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

# HDL cholesterol
m0 =  summary(lm(hdl ~ age + sex, data=pg))
m1 =  summary(lm(hdl ~ age + sex + scale(predicted_hdl) + scale(hdl_pgrs), data=pg))
m2 =  summary(lm(hdl ~ age + sex + scale(predicted_hdl), data=pg))
m3 =  summary(lm(hdl ~ age + sex + scale(hdl_pgrs), data=pg))
hdl_r_add <- 100*(m1$r.squared - m0$r.squared)
hdl_r_meth <- 100*(m2$r.squared - m0$r.squared)
hdl_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

# LDL cholesterol
m0 =  summary(lm(ldl ~ age + sex, data=pg))
m1 =  summary(lm(ldl ~ age + sex + scale(predicted_ldl) + scale(ldl_pgrs), data=pg))
m2 =  summary(lm(ldl ~ age + sex + scale(predicted_ldl), data=pg))
m3 =  summary(lm(ldl ~ age + sex + scale(ldl_pgrs), data=pg))
ldl_r_add <- 100*(m1$r.squared - m0$r.squared)
ldl_r_meth <- 100*(m2$r.squared - m0$r.squared)
ldl_r_pgrs <- 100*(m3$r.squared - m0$r.squared)

# Ratio
m0 =  summary(lm(ratio ~ age + sex, data=pg))
m2 =  summary(lm(ratio ~ age + sex + scale(predicted_ratio), data=pg))
ratio_r_meth <- 100*(m2$r.squared - m0$r.squared)




plot_data <- data.frame("Phenotype"=c(rep("BMI", 3), rep("Education", 3),  
                                      rep("Smoking", 3), rep("Alcohol", 3),
                                      rep("TC", 3), rep("HDL", 3),  
                                      rep("LDL", 3), rep("TC:HDL", 3)),
		                "Score" = rep(c("DNAm", "Polygenic", 
						                "Polygenic + DNAm"), 8),
		                "R2" = c(bmi_r_meth, bmi_r_pgrs, bmi_r_add, 
		                         ea_r_meth, ea_r_pgrs, ea_r_add,
					             smk_r_meth, smk_r_pgrs, smk_r_add,
					             alc_r_meth, alc_r_pgrs, alc_r_add,
                       tc_r_meth, tc_r_pgrs, tc_r_add,
					             hdl_r_meth, hdl_r_pgrs, hdl_r_add,
					             ldl_r_meth, ldl_r_pgrs, ldl_r_add,
                       ratio_r_meth, NA, NA))
plot_data$Phenotype <- factor(plot_data$Phenotype, levels=c("BMI", "Smoking", 
                              "Alcohol", "Education", "TC", 
                              "HDL", "LDL","TC:HDL"))
plot_data$Score <- factor(plot_data$Score, levels=c("Polygenic", "DNAm", "Polygenic + DNAm"))

pdf("R2_plot.pdf")
ggplot(data=plot_data, aes(x=Phenotype, y=R2, colour=Score, 
       fill=Score)) + 
geom_bar(stat="identity", position="dodge", colour="black") + 
scale_fill_manual(values= brewer.pal(9, "Paired")[c(1,3,7)]) + 
ylab(expression(R^{2})) +
theme_gray() +
theme(legend.position = c(0.8,0.9)) + 
scale_y_continuous(breaks = seq(0,60,10))
# ggtitle(paste("Variance Explained by Score")) + 
# theme(plot.title = element_text(hjust = 0.5))
dev.off()

### For Toni's grant application 14-09-18 ### 
plot_data <- data.frame("Phenotype"=c(rep("Smoking", 3), rep("Alcohol", 3)),
		                "Score" = rep(c("DNAm", "Polygenic", 
						                "Polygenic + DNAm"), 2),
		                "R2" = c(smk_r_meth, smk_r_pgrs, smk_r_add,
					             alc_r_meth, alc_r_pgrs, alc_r_add
                       ))
plot_data$Phenotype <- factor(plot_data$Phenotype, levels=c("Smoking", 
                              "Alcohol"))
plot_data$Score <- factor(plot_data$Score, levels=c("Polygenic", "DNAm", "Polygenic + DNAm"))

pdf("R2_plot_for_Toni.pdf")
ggplot(data=plot_data, aes(x=Phenotype, y=R2, colour=Score, 
       fill=Score)) + 
geom_bar(stat="identity", position="dodge", colour="black") + 
scale_fill_manual(values= brewer.pal(9, "Paired")[c(1,3,7)]) + 
ylab(expression(R^{2})) +
theme_gray() +
theme(legend.position = c(0.8,0.9)) + 
scale_y_continuous(breaks = seq(0,60,10))
# ggtitle(paste("Variance Explained by Score")) + 
# theme(plot.title = element_text(hjust = 0.5))
dev.off()

###############

# Read in updated survival data
dead <- read.spss("../LBC1936_MortalityDataUpdate_RM_27FEB2018.sav", to.data.frame=T)

dead$age_event = ifelse(!is.na(dead$agedays_death), 
                 dead$agedays_death, 
                 dead$agedaysApx_LastCensor)
dead$event = ifelse(is.na(dead$dead), 0, 1)

dead$lbc36no = trimws(dead$lbc36no, which = c("right"))
# pg$ID <- as.character(pg$ID)
pg$age_event <- dead[match(pg$ID, dead$lbc36no), "age_event"]
pg$event <- dead[match(pg$ID, dead$lbc36no), "event"]
# pg = merge(pg, dead[,c(1,6,7)], by.x="ID", by.y="lbc36no")
pg$age_event <- pg$age_event/365.25

# coxph(Surv(ttfu, event) ~ sex + age + bmi, data=data) 
# ttfu = age_event - age
pg$ttfu <- pg$age_event - pg$age
# Correct for WBC counts and technical factors
wbc <- read.table("../LBC1921_w1_w5_LBC1936_w1_w4_DNAmAge_11Sep2017.txt", 
                  sep='\t', header=T)
wbc <- wbc[which(wbc$ID %in% pg$ID & wbc$WAVE==1),]
pg <- merge(pg, wbc[,c("ID", "date", "array", "pos", "plate", 
                    "neut", "lymph", "mono", "eosin", "baso")], 
                    by.y="ID", all=F) %>% droplevels
cox_bmi_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(bmi) + scale(predicted_bmi) + scale(bmi_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))
                        
cox_smk_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + factor(smk) + scale(predicted_smk) + scale(smk_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_alc_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(alc) + scale(predicted_alc) + scale(alc_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_ea_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(EA) + scale(predicted_ea) + scale(ea_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))

cox_tc_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(tc) + scale(predicted_tc) + scale(tc_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
cox_hdl_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(hdl) + scale(predicted_hdl) + scale(hdl_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))       

cox_ldl_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ldl) + scale(predicted_ldl) + scale(ldl_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        
                        
cox_ratio_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ratio) + scale(predicted_ratio) +
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        

cox_whr_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_whr) + scale(whr_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))                                  

cox_bodyfat_fplot <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_fat) + scale(bodyfat_pgrs) +
                        neut + lymph + mono + eosin + baso, data=pg))            

                        

forestmat <- matrix(ncol=3)
colnames(forestmat) <- c("HR", "lowerCI", "upperCI")
models <- c("cox_bmi_fplot", "cox_alc_fplot", "cox_smk_fplot", 
            "cox_ea_fplot", "cox_tc_fplot", "cox_hdl_fplot", 
            "cox_ldl_fplot", "cox_ratio_fplot", "cox_whr_fplot", 
            "cox_bodyfat_fplot")#, "cox_ea_pgrs_meth")
		   
for(i in models) {
print(i)
    if(i == "cox_smk_fplot") {
	    forestmat <- rbind(forestmat, 
                   get(i)$conf.int[3:6,c(1,3,4)])# former,current, dnam, pgrs
	    } 
    else if(i == "cox_whr_fplot") {
      forestmat <- rbind(forestmat, 
                         c("","",""), #pheno blank
                         c("","",""), #pheno blank
                         get(i)$conf.int[3:4,c(1,3,4)]) #dnam + pgrs
                         
      }
    else if(i == "cox_bodyfat_fplot") {
      forestmat <- rbind(forestmat, 
                         c("","",""), #pheno blank
                         c("","",""), #pheno blank
                         get(i)$conf.int[3:4,c(1,3,4)]) #dnam + pgrs
      }       
    else if(i == "cox_ratio_fplot") { 
      forestmat <- rbind(forestmat, 
                         get(i)$conf.int[3,c(1,3,4)], #pheno
                         c("","",""), #pheno blank
                         get(i)$conf.int[4,c(1,3,4)],#dnam 
                         c("","","")) # pgrs blank)
    } else {
		  forestmat <- rbind(forestmat, 
      get(i)$conf.int[3,c(1,3,4)],
      c("","",""), # blank phenotype
      get(i)$conf.int[4:5,c(1,3,4)]) # dnam plus pgrs
	}
print(nrow(forestmat))
}
forestmat <- forestmat[-1,]
# forestmat <- rbind(forestmat[1:7,], c("","",""), forestmat[8:nrow(forestmat),]) # why did I do this?


forest_plot <- data.frame(forestmat)
forest_plot$Phenotype <- factor(c(rep("BMI",4),
                           rep("Alcohol", 4),
						   rep("Smoking", 4),
						   rep("Education", 4),
               rep("TC", 4),
               rep("HDL", 4),
               rep("LDL", 4),
               rep("TC_HDL_Ratio", 4),
               rep("WHR", 4),
               rep("Body_Fat", 4)),
						 levels=rev(c("BMI", "Alcohol", "Smoking", "Education", 
                          "TC", "HDL", "LDL", "TC_HDL_Ratio",
                          "WHR", "Body_Fat")))
  forest_plot$Trait <- factor(c(rep(c("Phenotypic", "", "DNAm", "Polygenic"), 2),
                              c("Phenotypic (Former)", "Phenotypic (Current)", 
                                "DNAm", "Polygenic"),
                              rep(c("Phenotypic", "", "DNAm", "Polygenic"),4),
                              c("Phenotypic", "", "DNAm", " "),
                              rep(c("", " ", "DNAm", "Polygenic"),2)),
                              levels=c(" ", "Polygenic", "DNAm" ,"",  "Phenotypic (Current)", "Phenotypic (Former)", "Phenotypic"))
   
forest_plot[,1:3] <- apply(forest_plot[,1:3], 2, function(x){signif(as.numeric(x), 3)})
   
					
  for(i in c("BMI", "Alcohol", "Smoking", "Education", 
             "TC", "HDL", "LDL", "TC_HDL_Ratio", "WHR", "Body_Fat")) {
  assign(paste0("fp_", gsub(" |\\(|\\)", "_", i)), 
         ggplot(data=forest_plot[which(forest_plot$Phenotype==i), ], 
               aes(x=factor(Trait), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle(paste(i)) + 
          theme(plot.title = element_text(hjust = 0.5))) # use a white background
         
          

  print(pdf(paste0("Forest_plot_", gsub(" |\\(|\\)", "_", i), "_updatedsurvival.pdf")))
  print(get(paste0("fp_", gsub(" |\\(|\\)", "_", i))))
  print(dev.off())
  }

# Forest plot of DNAm only
         pdf("DNAm_scores_only.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait=="DNAm"), ]
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=plot_tmp$Phenotype)
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("DNA Methylation Scores") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)

# Forest plot of PGRS only
         pdf("PGRS_only.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait=="Polygenic"), ]
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=plot_tmp$Phenotype)
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("Polygenic Risk Scores") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)
  

# Forest plot of Phenotypes only
         pdf("Phenotypes_only.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait%in%c("Phenotypic", "Phenotypic (Former)", "Phenotypic (Current)")), ]
         plot_tmp$Phenotype <- as.character(plot_tmp$Phenotype)
         plot_tmp[which(plot_tmp$Trait == "Phenotypic (Former)"),"Phenotype"] <- "Former Smoker"
         plot_tmp[which(plot_tmp$Trait == "Phenotypic (Current)"),"Phenotype"] <- "Current Smoker"
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=unique(plot_tmp$Phenotype))
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("Phenotypes") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)
  
# For Bioinformatics talk
         pdf("DNAm_scores_4_traits.pdf")
         plot_tmp <- forest_plot[which(forest_plot$Trait=="DNAm" & 
                                 forest_plot$Phenotype %in% c("BMI", "Smoking", "Alcohol", "Education")), ]
         plot_tmp <- plot_tmp[order(plot_tmp$HR, decreasing=T),]
         plot_tmp$Phenotype <- factor(plot_tmp$Phenotype, levels=plot_tmp$Phenotype)
         ggplot(data=plot_tmp, 
               aes(x=factor(Phenotype), y=HR, 
         ymin=lowerCI, ymax=upperCI)) +
          geom_pointrange() + 
          geom_hline(yintercept=1, lty=2) +  # add a dotted line at x=1 after flip
        xlab(" ") + 
        ylab("HR (95% CI)") +
        coord_flip() + # flip coordinates (puts labels on y axis)        
          theme_bw() + 
      ggtitle("DNA Methylation Scores") + 
          theme(plot.title = element_text(hjust = 0.5)) # use a white background
dev.off()
  rm(plot_tmp)
  
# Tabulate statistics

					
pg$obese = ifelse(pg$bmi>30 & !is.na(pg$bmi),1, 
			ifelse(pg$bmi<=30 & !is.na(pg$bmi),0, NA))
pg$drinker = ifelse(pg$alc>21 & !is.na(pg$alc) & pg$sex == "M",1,
			ifelse(pg$alc<=21 & !is.na(pg$alc) & pg$sex == "M",0, NA))
pg$drinker[which(pg$sex=="F" & pg$alc >14)] <- 1
pg$drinker[which(pg$sex=="F" & pg$alc <=14)] <- 0

pg$smk_current_never <- pg$smk
pg$smk_current_never[pg$smk_current_never==1] <- NA
pg$smk_current_never[pg$smk_current_never==2] <- 1

pg$college = ifelse(pg$EA>11 & !is.na(pg$EA),1,
			ifelse(pg$EA<=11 & !is.na(pg$EA),0,NA))
      
pg$high_tc <- ifelse(pg$tc>5 & !is.na(pg$tc),1,
			ifelse(pg$tc<=5 & !is.na(pg$tc),0,NA))
      
pg$high_hdl <- ifelse(pg$hdl>1 & !is.na(pg$hdl),1,
			ifelse(pg$hdl<=1 & !is.na(pg$hdl),0,NA))
 
pg$high_ldl <- ifelse(pg$ldl>3 & !is.na(pg$ldl),1,
			ifelse(pg$ldl<=3 & !is.na(pg$ldl),0,NA))
      
pg$high_ratio <- ifelse(pg$ratio>=4 & !is.na(pg$ratio),1,
			ifelse(pg$ratio<4 & !is.na(pg$ratio),0,NA))

curvecols <- brewer.pal(10, "Paired")
pdf("ROC curves of univariate models (lifestyle).pdf")
plot(roc(obese ~ predicted_bmi , data=pg), col=curvecols[2], main="AUCs")
plot(roc(drinker ~ predicted_alc , data=pg), add=T, col=curvecols[4])
plot(roc(smk_current_never ~ predicted_smk , data=pg), add=T, col=curvecols[6])
plot(roc(college ~ predicted_ea , data=pg), add=T, col=curvecols[8])
# Extract AUCS programatically in case of errors
legend("bottomright", c(paste("Current smoker: AUC = ",
       paste(signif(as.numeric(roc(smk_current_never ~ predicted_smk , data=pg)$auc),2))), 
	   paste("Heavy drinker: AUC = ", 
	   paste(signif(as.numeric(roc(drinker ~ predicted_alc , data=pg)$auc),2))), 
	   paste("Obese: AUC = ",
	   paste(signif(as.numeric(roc(obese ~ predicted_bmi , data=pg)$auc),2))),
	   paste("College Educated: AUC = ",
	   paste(signif(as.numeric(roc(college ~ predicted_ea , data=pg)$auc),2)))),
     bty="n", text.col=curvecols[c(6,4,2,8)])
     dev.off() 

pdf("ROC curves of univariate models (cholesterol).pdf")     
plot(roc(high_hdl ~ predicted_hdl , data=pg), main="AUCs", col=curvecols[4])
plot(roc(high_tc ~ predicted_tc , data=pg),  add=T, col=curvecols[2])
plot(roc(high_ratio ~ predicted_ratio , data=pg), add=T, col=curvecols[8])
plot(roc(high_ldl ~ predicted_ldl , data=pg), add=T, col=curvecols[6])

# Extract AUCS programatically in case of errors
legend("bottomright", c(paste("High vs Low HDL: AUC = ", 
	   paste(signif(as.numeric(roc(high_hdl ~ predicted_hdl, data=pg)$auc),2))), 
     paste("High vs Low TC: AUC = ", 
	   paste(signif(as.numeric(roc(high_tc ~ predicted_tc , data=pg)$auc),2))),      
     paste("High vs Low Ratio: AUC = ", 
	   paste(signif(as.numeric(roc(high_ratio ~ predicted_ratio , data=pg)$auc),2))),     
     paste("High vs Low LDL: AUC = ", 
	   paste(signif(as.numeric(roc(high_ldl ~ predicted_ldl , data=pg)$auc),2)))),      
	   bty="n", text.col=curvecols[c(4,2,8,6)])
	   dev.off()
	   
# Use ggplot for prettier ROC curves (lifestyle)
smk <- pg[,c("smk_current_never", "predicted_smk")]
smk$Phenotype = paste0("Current Smoker (AUC = ", 
signif(as.numeric(roc(smk_current_never ~ predicted_smk, data=pg)$auc),2),
")")
smk$Colour <- brewer.pal(9, "Paired")[1]

bmi <- pg[,c("obese", "predicted_bmi")]
bmi$Phenotype = paste0("Obese (AUC = ", 
signif(as.numeric(roc(obese ~ predicted_bmi, data=pg)$auc),2),
")")
bmi$Colour <- brewer.pal(9, "Paired")[3]

alc <- pg[,c("drinker", "predicted_alc")]
alc$Phenotype = paste0("Moderate-to-Heavy Drinker (AUC = ", 
signif(as.numeric(roc(drinker ~ predicted_alc, data=pg)$auc),2),
")")
alc$Colour <- brewer.pal(9, "Paired")[7]

ea <- pg[,c("college", "predicted_ea")]
ea$Phenotype = paste0("College Educated (AUC = ", 
signif(as.numeric(roc(college ~ predicted_ea, data=pg)$auc),2),
")")
ea$Colour <- brewer.pal(9, "Paired")[9]
names(smk)[1:2] <- names(bmi)[1:2] <- names(alc)[1:2] <- names(ea)[1:2] <- c("Class", "Score")

new_roc_lifestyle <- rbind(smk, bmi, alc, ea)

# Reorder so highest auc is first factor level
factorlevs <- levels(factor(new_roc_lifestyle$Phenotype))
new_roc_lifestyle$Phenotype <- as.factor(new_roc_lifestyle$Phenotype) 
new_roc_lifestyle$Phenotype <- factor(new_roc_lifestyle$Phenotype, 
levels=c(factorlevs[2], factorlevs[3], factorlevs[4], factorlevs[1]))

#Conf intervals



pdf("AUCS_ggplot_lifestyle.pdf")
ggplot(new_roc_lifestyle, aes(d=Class, m=Score, color=Phenotype)) + 
geom_roc(n.cuts=0) + 
xlab("False Positive Rate (1 - Specificity)") +
ylab("True Positive Rate (Sensitivity)") + 
theme_gray() + 
ggtitle("AUCS") + 
theme(plot.title = element_text(hjust = 0.5)) +
theme(legend.position = c(0.7, 0.2))+ 
scale_colour_manual(values = brewer.pal(9, "Paired")[c(2,4,7,9)],
                       guide = guide_legend(override.aes = list(
                         linetype =rep("solid", 4)))) + 
geom_abline(slope=1,intercept=0, color="black")
dev.off()


# Use ggplot for prettier ROC curves (Cholesterol)
tc <- pg[,c("high_tc", "predicted_tc")]
tc$Phenotype = paste0("High Total Cholesterol (AUC = ", 
signif(as.numeric(roc(high_tc ~ predicted_tc, data=pg)$auc),2),
")")
tc$Colour <- brewer.pal(9, "Paired")[1]

hdl <- pg[,c("high_hdl", "predicted_hdl")]
hdl$Phenotype = paste0("High HDL Cholesterol (AUC = ", 
signif(as.numeric(roc(high_hdl ~ predicted_hdl, data=pg)$auc),2),
")")
hdl$Colour <- brewer.pal(9, "Paired")[3]

ldl <- pg[,c("high_ldl", "predicted_ldl")]
ldl$Phenotype = paste0("High LDL Cholesterol (AUC = ", 
signif(as.numeric(roc(high_ldl ~ predicted_ldl, data=pg)$auc),2),
")")
ldl$Colour <- brewer.pal(9, "Paired")[7]

ratio <- pg[,c("high_ratio", "predicted_ratio")]
ratio$Phenotype = paste0("High TC:HDL Ratio (AUC = ", 
signif(as.numeric(roc(high_ratio ~ predicted_ratio, data=pg)$auc),2),
")")
ratio$Colour <- brewer.pal(9, "Paired")[9]
names(tc)[1:2] <- names(hdl)[1:2] <- names(ldl)[1:2] <- names(ratio)[1:2] <- c("Class", "Score")

new_roc_cholesterol <- rbind(hdl, tc, ratio, ldl)

# Reorder so highest auc is first factor level
new_roc_cholesterol$Phenotype <- as.factor(new_roc_cholesterol$Phenotype) 
new_roc_cholesterol$Phenotype <- gsub("0.7\\)", "0\\.70\\)", new_roc_cholesterol$Phenotype)
factorlevs <- levels(factor(new_roc_cholesterol$Phenotype))
new_roc_cholesterol$Phenotype <- factor(new_roc_cholesterol$Phenotype, 
levels=c(factorlevs[1], factorlevs[3], factorlevs[4], factorlevs[2]))

#AUCS and Conf intervals
tc_auc <- roc(high_tc~predicted_tc, data=pg, ci=T)$auc
hdl_auc <- signif(roc(high_hdl~predicted_hdl, data=pg, ci=T)$auc,2) 
hdl_auc <- format(round(hdl_auc,2), nsmall = 2)
ldl_auc <- roc(high_ldl~predicted_ldl, data=pg, ci=T)$auc
ratio_auc <- roc(high_ratio~predicted_ratio, data=pg, ci=T)$auc

tc_ci <- roc(high_tc~predicted_tc, data=pg, ci=T)$ci
hdl_ci <- roc(high_hdl~predicted_hdl, data=pg, ci=T)$ci
ldl_ci <- roc(high_ldl~predicted_ldl, data=pg, ci=T)$ci
ratio_ci <- roc(high_ratio~predicted_ratio, data=pg, ci=T)$ci



pdf("AUCS_ggplot_cholesterol.pdf")
  ggplot(new_roc_cholesterol, aes(d=Class, m=Score, color=Phenotype)) + 
  geom_roc(n.cuts=0) + 
  xlab("False Positive Rate (1 - Specificity)") +
  ylab("True Positive Rate (Sensitivity)") + 
  theme_gray() + 
  ggtitle("AUCS") + 
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(legend.position = c(0.7, 0.2))+ 
  scale_colour_manual(values = brewer.pal(9, "Paired")[c(2,4,7,9)],
                         guide = guide_legend(override.aes = list(
                           linetype =rep("solid", 4)))) + 
  geom_abline(slope=1,intercept=0, color="black")
dev.off()

pdf("AUCS_for_paper v2.pdf", width=13, height=8)
plot1 <- ggplot(new_roc_lifestyle, aes(d=Class, m=Score, color=Phenotype)) + 
geom_roc(n.cuts=0) + 
xlab("False Positive Rate (1 - Specificity)") +
ylab("True Positive Rate (Sensitivity)") + 
theme_gray() + 
theme(plot.title = element_text(hjust = 0.5)) +
theme(legend.position = c(0.7, 0.2))+ 
theme(text = element_text(size=13)) + 
scale_colour_manual(values = brewer.pal(9, "Paired")[c(2,4,7,9)],
                       guide = guide_legend(override.aes = list(
                         linetype =rep("solid", 4)))) + 
geom_abline(slope=1,intercept=0, color="black")
plot2 <- ggplot(new_roc_cholesterol, aes(d=Class, m=Score, color=Phenotype)) + 
  geom_roc(n.cuts=0) + 
  xlab("False Positive Rate (1 - Specificity)") +
  ylab("True Positive Rate (Sensitivity)") + 
  theme_gray() + 
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(legend.position = c(0.7, 0.2))+ 
  scale_colour_manual(values = brewer.pal(9, "Paired")[c(2,4,7,9)],
                         guide = guide_legend(override.aes = list(
                           linetype =rep("solid", 4)))) + 
  theme(text = element_text(size=13)) + 
  geom_abline(slope=1,intercept=0, color="black")
grid.arrange(plot1, plot2, ncol=2)
dev.off()




# Final sentences of AUC section in paper:
glm_bmi <- (glm(obese ~ scale(predicted_bmi) + scale(bmi_pgrs), data=pg, family=binomial(logit)))
glm_alc <- (glm(drinker ~ scale(predicted_alc) + scale(alc_pgrs), data=pg, family=binomial(logit)))
glm_ea <- (glm(college ~ scale(predicted_ea) + scale(ea_pgrs), data=pg, family=binomial(logit)))
glm_smk <- (glm(smk_current_never ~ scale(predicted_smk) + scale(smk_pgrs), data=pg, family=binomial(logit)))
glm_tc <- (glm(high_tc ~ scale(predicted_tc) + scale(tc_pgrs), data=pg, family=binomial(logit)))
glm_hdl <- (glm(high_hdl ~ scale(predicted_hdl) + scale(hdl_pgrs), data=pg, family=binomial(logit)))
glm_ldl <- (glm(high_ldl ~ scale(predicted_ldl) + scale(ldl_pgrs), data=pg, family=binomial(logit)))

bmi_pgrs_auc <- roc(glm_bmi$y , glm_bmi$fitted.values, ci=T)$auc
bmi_pgrs_ci <- roc(glm_bmi$y , glm_bmi$fitted.values, ci=T)$ci
alc_pgrs_auc <- roc(glm_alc$y , glm_alc$fitted.values, ci=T)$auc
alc_pgrs_ci <- roc(glm_alc$y , glm_alc$fitted.values, ci=T)$ci
ea_pgrs_auc <- roc(glm_ea$y , glm_ea$fitted.values, ci=T)$auc
ea_pgrs_ci <- roc(glm_ea$y , glm_ea$fitted.values, ci=T)$ci
smk_pgrs_auc <- roc(glm_smk$y , glm_smk$fitted.values, ci=T)$auc
smk_pgrs_ci <- roc(glm_smk$y , glm_smk$fitted.values, ci=T)$ci
tc_pgrs_auc <- roc(glm_tc$y , glm_tc$fitted.values, ci=T)$auc
tc_pgrs_ci <- roc(glm_tc$y , glm_tc$fitted.values, ci=T)$ci
hdl_pgrs_auc <- roc(glm_hdl$y , glm_hdl$fitted.values, ci=T)$auc
hdl_pgrs_ci <- roc(glm_hdl$y , glm_hdl$fitted.values, ci=T)$ci
ldl_pgrs_auc <- roc(glm_ldl$y , glm_ldl$fitted.values, ci=T)$auc
ldl_pgrs_ci <- roc(glm_ldl$y , glm_ldl$fitted.values, ci=T)$ci

glm_bmi_smk <- (glm(obese ~ scale(predicted_bmi) + scale(bmi_pgrs) + scale(predicted_smk), data=pg, family=binomial(logit)))
glm_alc_smk <- (glm(drinker ~ scale(predicted_alc) + scale(alc_pgrs) +  scale(predicted_smk), data=pg, family=binomial(logit)))
glm_ea_smk <- (glm(college ~ scale(predicted_ea) + scale(ea_pgrs) + scale(predicted_smk), data=pg, family=binomial(logit)))
glm_tc_smk <- (glm(high_tc ~ scale(predicted_tc) + scale(tc_pgrs) + scale(predicted_smk), data=pg, family=binomial(logit)))
glm_hdl_smk <- (glm(high_hdl ~ scale(predicted_hdl) + scale(hdl_pgrs) + scale(predicted_smk), data=pg, family=binomial(logit)))
glm_ldl_smk <- (glm(high_ldl ~ scale(predicted_ldl) + scale(ldl_pgrs) + scale(predicted_smk), data=pg, family=binomial(logit)))
glm_ratio_smk <- (glm(high_ratio ~ scale(predicted_ratio) + scale(predicted_smk), data=pg, family=binomial(logit)))


# # Plot correlation matrix  gs (lower diagonal=epigenetic score, upper diagonal=phenotypic score)
phenocor <- cor(d4[,c("bmi", "pack_years", "units", "years", "Total_cholesterol", "HDL_cholesterol", 
                     "LDL_with_Remnant_Cholesterol", "HDL_Ratio", "whr", "body_fat")], 
                use="pairwise.complete.obs")
myColor <- colorRampPalette(c("blue", "white", "red"))(120)
# length(breaks) == length(paletteLength) + 1
# use floor and ceiling to deal with even/odd length pallettelengths
hm_plot <- phenocor              

myBreaks <- c(seq(min(sort(hm_plot)), 0, length.out=ceiling(120/2) + 1), 
              seq(1/120, 1, length.out=floor(120/2)))
  hm_plot[upper.tri(hm_plot,diag=FALSE)] <- NA
  rownames(hm_plot) <- colnames(hm_plot) <- c("BMI", "Smoking", "Alcohol", "Education", "Total Cholesterol", 
                                              "HDL", "LDL with remnant", "Total:HDL Ratio", "Waist-Hip Ratio", 
                                              "% Body Fat")
  hm_plot <- apply(hm_plot,2,function(x){signif(x,1)})
pdf("CorrelationMatrix_GS_Phenos_SuppFigure1.pdf", onefile=FALSE)
heatmap.2(hm_plot, Rowv=NULL, Colv=NULL, 
        col=myColor, breaks=myBreaks,
		  dendrogram="none", tracecol=F, key=TRUE, cellnote=hm_plot, 
      main = paste0("GS Phenotype Correlations"),
		  notecol="black", cexRow=0.4, cexCol=0.4)
      dev.off()

# Use my_hm2 function to move axis labels
 source("M:/lasso_prediction/my_hm2.r")
# # Plot correlation matrix  LBC (lower diagonal=epigenetic score, upper diagonal=phenotypic score)
phenocor <- cor(pg[,c("bmi", "smk", "alc", "EA", "tc", "hdl", "ldl", "ratio")], 
                use="pairwise.complete.obs")
epicor <- cor(pg[,c("predicted_bmi", "predicted_smk", "predicted_alc", 
                      "predicted_ea", "predicted_tc", "predicted_hdl",
                      "predicted_ldl", "predicted_ratio", "predicted_whr",
                      "predicted_fat")], 
              use="pairwise.complete.obs")
pgcor <-   cor(pg[,c("bmi_pgrs", "smk_pgrs", "alc_pgrs", "ea_pgrs", 
                       "tc_pgrs", "hdl_pgrs", "ldl_pgrs", "whr_pgrs", "bodyfat_pgrs")], 
                use="pairwise.complete.obs")               
			  
mixed_cor <- matrix(nrow=30, ncol=30)
colnames(phenocor) <- rownames(phenocor) <- c("BMI", "Smoking", "Alcohol", "Education",
                                                  "TC", "HDL", "LDL", "Ratio")
colnames(epicor) <- rownames(epicor) <- c("BMI DNAm", "Smoking DNAm", "Alcohol DNAm", "Education DNAm",
                                                  "TC DNAm", "HDL DNAm", "LDL DNAm", "Ratio DNAm", "WHR DNAm", "% Body fat DNAm")                                                  
colnames(pgcor) <- rownames(pgcor) <- c("BMI PGRS", "Smoking PGRS", "Alcohol PGRS", "Education PGRS",
                                                  "TC PGRS", "HDL PGRS", "LDL PGRS", "WHR PGRS", "% Body fat PGRS")                                                  
phenoepi_cor <- cor(pg[,c("bmi", "smk", "alc", "EA", "tc", "hdl", "ldl", "ratio", 
                        "predicted_bmi", "predicted_smk", "predicted_alc", 
                      "predicted_ea", "predicted_tc", "predicted_hdl",
                      "predicted_ldl", "predicted_ratio", "predicted_whr",
                      "predicted_fat")], use="pairwise.complete.obs")
colnames(phenoepi_cor) <- rownames(phenoepi_cor) <- c("BMI", "Smoking", "Alcohol", "Education",
                                                  "TC", "HDL", "LDL", "Ratio",
                                                  "BMI DNAm", "Smoking DNAm", "Alcohol DNAm", 
                                                  "Education DNAm", "TC DNAm", "HDL DNAm", "LDL DNAm",
                                                  "Ratio DNAm", "WHR DNAm", "% Body fat DNAm")                                                  
phenopgrs_cor <- cor(pg[,c("bmi", "smk", "alc", "EA", "tc", "hdl", "ldl", "ratio", "bmi_pgrs", "smk_pgrs", "alc_pgrs", "ea_pgrs", 
                       "tc_pgrs", "hdl_pgrs", "ldl_pgrs", "whr_pgrs", "bodyfat_pgrs")], use="pairwise.complete.obs")
colnames(phenopgrs_cor) <- rownames(phenopgrs_cor) <- c("BMI", "Smoking", "Alcohol", "Education",
                                                  "TC", "HDL", "LDL", "Ratio",
                                                  "BMI PGRS", "Smoking PGRS", "Alcohol PGRS", 
                                                  "Education PGRS", "TC PGRS", "HDL PGRS", "LDL PGRS",
                                                  "WHR PGRS", "% Body fat PGRS")                                                  
                       
pgrsepi_cor <- cor(pg[,c("predicted_bmi", "predicted_smk", "predicted_alc", 
                      "predicted_ea", "predicted_tc", "predicted_hdl",
                      "predicted_ldl", "predicted_ratio", "predicted_whr",
                      "predicted_fat", "bmi_pgrs", "smk_pgrs", "alc_pgrs", "ea_pgrs", 
                       "tc_pgrs", "hdl_pgrs", "ldl_pgrs", "whr_pgrs", "bodyfat_pgrs")], use="pairwise.complete.obs") 
colnames(pgrsepi_cor) <- rownames(pgrsepi_cor) <- c("BMI DNAm", "Smoking DNAm", "Alcohol DNAm", 
                                                  "Education DNAm", "TC DNAm", "HDL DNAm", "LDL DNAm",
                                                  "Ratio DNAm", "WHR DNAm", "% Body fat DNAm",
                                                  "BMI PGRS", "Smoking PGRS", "Alcohol PGRS", 
                                                  "Education PGRS", "TC PGRS", "HDL PGRS", "LDL PGRS",
                                                  "WHR PGRS", "% Body fat PGRS")                                                  
                       
for(type in c("Phenotypic", "DNAm", "PGRS", "Phenotypic_DNAm", "Phenotypic_PGRS", "DNAm_PGRS")) {
key <- TRUE
cexrow <- cexcol <- 0.5
if(type=="Phenotypic") { 
hm_plot <- phenocor
}
if(type=="DNAm") { 
hm_plot <- epicor
}
if(type=="PGRS") { 
hm_plot <- pgcor
}
if(type=="Phenotypic_DNAm") { 
# key <- FALSE
hm_plot <- phenoepi_cor
}
if(type=="Phenotypic_PGRS") { 
# key <- FALSE
hm_plot <- phenopgrs_cor
}
if(type=="DNAm_PGRS") { 
# key <- FALSE
hm_plot <- pgrsepi_cor
}
myColor <- colorRampPalette(c("blue", "white", "red"))(120)
# length(breaks) == length(paletteLength) + 1
# use floor and ceiling to deal with even/odd length pallettelengths
myBreaks <- c(seq(min(sort(hm_plot)), 0, length.out=ceiling(120/2) + 1), 
              seq(1/120, 1, length.out=floor(120/2)))
  hm_plot[upper.tri(hm_plot,diag=FALSE)] <- NA
  rownames(hm_plot) <- colnames(hm_plot)
  hm_plot <- apply(hm_plot,2,function(x){signif(x,1)})
pdf(paste0("CorrelationMatrix_", type, ".pdf"), onefile=FALSE)
print(my_hm2(hm_plot, Rowv=NULL, Colv=NULL, 
        col=myColor, breaks=myBreaks,
		  dendrogram="none", tracecol=F, key=key, cellnote=hm_plot, 
      main = paste0("LBC 1936 ", type, " Scores"),
		  notecol="black", cexRow=cexrow, cexCol=cexcol))
paste(dev.off())
}

# hm_plot <- allcor
# hm_plot <- apply(hm_plot, 2, function(x){signif(x,2)})
# rownames(hm_plot) <- colnames(hm_plot)
# pdf("CorrelationMatrix_Heatmap_PhenoEpi_8x8.pdf")
# heatmap.2(hm_plot, Rowv=NULL, Colv=NULL, 
          # col=colorRampPalette(c("blue","white","red"))(256), 
		  # dendrogram="none", tracecol=F, key=F, cellnote=hm_plot, 
		  # notecol="black")#, cexRow=0.5, cexCol=0.5)
		  # # Optional: separate tiles
		  # #colsep=1:4, rowsep=1:4, sepcolor="black")
# dev.off()


                    
                       
                        
cox_bmi_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(bmi) + scale(predicted_bmi) + scale(bmi_pgrs) + 
                        # # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_alc_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(alc) + scale(predicted_alc) + scale(alc_pgrs) +
                        # factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_ea_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(EA) + scale(predicted_ea) + scale(ea_pgrs) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_tc_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(tc) + scale(predicted_tc) + scale(tc_pgrs) +
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_hdl_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(hdl) + scale(predicted_hdl) + scale(hdl_pgrs) +
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_ldl_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ldl) + scale(predicted_ldl) + scale(ldl_pgrs) +
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))
cox_ratio_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ratio) + scale(predicted_ratio) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))                        
cox_fat_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex  + scale(predicted_fat) + scale(bodyfat_pgrs) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))                        
cox_whr_cond_smk_supp <- summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_whr) + scale(whr_pgrs) + 
                      #  factor(date) + factor(array) + factor(pos) + factor(plate) + 
                        scale(predicted_smk) + neut + lymph + mono + eosin + baso, data=pg))                                        
                        
supp_cond_meth_smk <- matrix(ncol=3, nrow=33)

colnames(supp_cond_meth_smk) <-c("HR", "95% CI", "P")



                              
rownames(supp_cond_meth_smk) <- c("Phenotypic BMI", "DNAm BMI", "PGRS BMI", "DNAm Smoking BMI",
                              "Phenotypic Alcohol", "DNAm Alcohol", "PGRS Alcohol", "DNAm Smoking Alcohol",
                              "Phenotypic Education", "DNAm Education", "PGRS Education", "DNAm Smoking Education",
                              "Phenotypic Total Cholesterol", "DNAm Total Cholesterol", "PGRS Total_Cholesterol", "DNAm Smoking Total Cholesterol",
                              "Phenotypic HDL Cholesterol", "DNAm HDL Cholesterol",  "PGRS HDL_Cholesterol", "DNAm Smoking HDL Cholesterol",
                              "Phenotypic LDL Cholesterol", "DNAm LDL Cholesterol",  "PGRS LDL_Cholesterol", "DNAm Smoking LDL Cholesterol",
                              "Phenotypic Total:HDL Ratio", "DNAm Total:HDL Ratio", "DNAm Smoking Total:HDL Ratio",
                              "DNAm WHR",  "PGRS WHR", "DNAm Smoking WHR",
                              "DNAm BodyFat",  "PGRS BodyFat", "DNAm Smoking BodyFat")



supp_cond_meth_smk[1:4,1] <- cox_bmi_cond_smk_supp$conf[3:6,1]
supp_cond_meth_smk[1:4,2] <- paste0(cox_bmi_cond_smk_supp$conf[3:6,3], " - ", cox_bmi_cond_smk_supp$conf[3:6,4])
supp_cond_meth_smk[1:4,3] <- cox_bmi_cond_smk_supp$coef[3:6,5]
supp_cond_meth_smk[5:8,1] <- cox_alc_cond_smk_supp$conf[3:6,1]
supp_cond_meth_smk[5:8,2] <- paste0(cox_alc_cond_smk_supp$conf[3:6,3], " - ", cox_alc_cond_smk_supp$conf[3:6,4])
supp_cond_meth_smk[5:8,3] <- cox_alc_cond_smk_supp$coef[3:6,5]
supp_cond_meth_smk[9:12,1] <- cox_ea_cond_smk_supp$conf[3:6,1]
supp_cond_meth_smk[9:12,2] <- paste0(cox_ea_cond_smk_supp$conf[3:6,3], " - ", cox_ea_cond_smk_supp$conf[3:6,4])
supp_cond_meth_smk[9:12,3] <- cox_ea_cond_smk_supp$coef[3:6,5]
supp_cond_meth_smk[13:16,1] <- cox_tc_cond_smk_supp$conf[3:6,1]
supp_cond_meth_smk[13:16,2] <- paste0(cox_tc_cond_smk_supp$conf[3:6,3], " - ", cox_tc_cond_smk_supp$conf[3:6,4])
supp_cond_meth_smk[13:16,3] <- cox_tc_cond_smk_supp$coef[3:6,5]
supp_cond_meth_smk[17:20,1] <- cox_hdl_cond_smk_supp$conf[3:6,1]
supp_cond_meth_smk[17:20,2] <- paste0(cox_hdl_cond_smk_supp$conf[3:6,3], " - ", cox_hdl_cond_smk_supp$conf[3:6,4])
supp_cond_meth_smk[17:20,3] <- cox_hdl_cond_smk_supp$coef[3:6,5]
supp_cond_meth_smk[21:24,1] <- cox_ldl_cond_smk_supp$conf[3:6,1]
supp_cond_meth_smk[21:24,2] <- paste0(cox_ldl_cond_smk_supp$conf[3:6,3], " - ", cox_ldl_cond_smk_supp$conf[3:6,4])
supp_cond_meth_smk[21:24,3] <- cox_ldl_cond_smk_supp$coef[3:6,5]
supp_cond_meth_smk[25:27,1] <- cox_ratio_cond_smk_supp$conf[3:5,1]
supp_cond_meth_smk[25:27,2] <- paste0(cox_ratio_cond_smk_supp$conf[3:5,3], " - ", cox_ratio_cond_smk_supp$conf[3:5,4])
supp_cond_meth_smk[25:27,3] <- cox_ratio_cond_smk_supp$coef[3:5,5]
supp_cond_meth_smk[28:30,1] <- cox_whr_cond_smk_supp$conf[3:5,1]
supp_cond_meth_smk[28:30,2] <- paste0(cox_whr_cond_smk_supp$conf[3:5,3], " - ", cox_whr_cond_smk_supp$conf[3:5,4])
supp_cond_meth_smk[28:30,3] <- cox_whr_cond_smk_supp$coef[3:5,5]
supp_cond_meth_smk[31:33,1] <- cox_fat_cond_smk_supp$conf[3:5,1]
supp_cond_meth_smk[31:33,2] <- paste0(cox_fat_cond_smk_supp$conf[3:5,3], " - ", cox_fat_cond_smk_supp$conf[3:5,4])
supp_cond_meth_smk[31:33,3] <- cox_fat_cond_smk_supp$coef[3:5,5]

write.table(supp_cond_meth_smk, file="Pheno_Meth_Smk_cox_celladj.xls", sep='\t', quote=F, col.names=NA)

save.image("Models_Figures_and_Tables_for_Paper_postreview.RData")

# Qian Zhang: correlation between GS variables?
gs_cor <- cor(d4[,c("bmi","pack_years","units","years")], use="pairwise.complete.obs")
rownames(gs_cor) <- colnames(gs_cor) <- c("BMI", "Smoking", "Alcohol", "Education")
write.table(gs_cor, file="correlation_gs_variables.xls", sep='\t', quote=F, col.names=NA)

# Potential additional figure:
# Smoking groups and scores (boxplot)
pg2 <- pg 
levels(factor(pg2$smk))
# [1] "0" "1" "2"
pg2$smk <- gsub("0", "Never smoker", pg2$smk)
pg2$smk <- gsub("1", "Former smoker", pg2$smk)
pg2$smk <- gsub("2", "Current smoker", pg2$smk)

pg2$smk <- factor(pg2$smk, levels=c("Never smoker" ,"Former smoker", "Current smoker"))

pdf("Smoking_boxplots.pdf")
ggplot(pg2, aes(factor(smk), y=scale(predicted_smk))) + 
scale_x_discrete(labels=c("Never smoker" ,"Former smoker", "Current smoker")) +
geom_boxplot(aes(fill=factor(smk))) + 
scale_color_manual(values = c("black", "black", "black")) + 
       xlab("Phenotypic Smoking") + 
	    ylab("DNAm smoking scores") +
		guides(fill=FALSE) + 
		# ggtitle(paste("DNAm Smoking score by phenotypic smoking group")) + 
		# theme(plot.title = element_text(hjust = 0.5)) + 
		theme_gray()
dev.off()


# Check correlation between age and hannum/horvath ages:
targets <- read.csv("../LBC1921_w1_w5_LBC1936_w1_w4_DNAmAge_11Sep2017.txt", sep='\t', header=T)
targets <- targets[which(targets$ID_raw %in% pg$ID & targets$WAVE==1),]
targets <- targets[match(pg$ID, targets$ID_raw),]
all.equal(as.character(targets$ID_raw), as.character(pg$ID))
# [1] TRUE

pg$IEAA <- targets[match(pg$ID, targets$ID_raw), "IEAA"]
pg$EEAA <- targets[match(pg$ID, targets$ID_raw), "EEAA"]
supp_mat <- matrix(nrow=20, ncol=4)
colnames(supp_mat) <- c("AgeAccel", "Score", "Cor", "P")
supp_mat[,1] <- c(rep("IEAA", 10), rep("EEAA", 10))
supp_mat[,2] <- rep(c("predicted_bmi", "predicted_smk", "predicted_alc", "predicted_ea", 
                      "predicted_tc", "predicted_hdl", "predicted_ldl", "predicted_ratio", 
                      "predicted_fat", "predicted_whr"), 2)

for(i in 1:nrow(supp_mat)) {
  tmp_cor <- cor.test(pg[,supp_mat[i,1]], pg[,supp_mat[i,2]])
  supp_mat[i,3] <- signif(tmp_cor$estimate, 3)
  supp_mat[i,4] <- signif(tmp_cor$p.value, 3)
  }
write.table(data.frame(supp_mat), file="reviewer_cor_ageaccel_table.xls", quote=F, sep='\t', row.names=F)

# IEAA and ea, tc, ldl, ratio, whr are correlated
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(EA) + scale(predicted_ea) + scale(ea_pgrs) + scale(IEAA) + 
                       neut + lymph + mono + eosin + baso, data=pg))
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(tc) + scale(predicted_tc) + scale(tc_pgrs) + scale(IEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                        
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ldl) + scale(predicted_ldl) + scale(ldl_pgrs) + scale(IEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))      
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ratio) + scale(predicted_ratio) + scale(IEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                                      
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(predicted_whr) + scale(whr_pgrs) + scale(IEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                                  
                        
# EEAA and smk, alc, ea, tc, ldl, and ratioare correlated                
summary(coxph(Surv(ttfu, event) ~ age + sex + factor(smk) + scale(predicted_smk) + scale(smk_pgrs) + scale(EEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(alc) + scale(predicted_alc) + scale(alc_pgrs) + scale(EEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(EA) + scale(predicted_ea) + scale(ea_pgrs) + scale(EEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))

summary(coxph(Surv(ttfu, event) ~ age + sex + scale(tc) + scale(predicted_tc) + scale(tc_pgrs) + scale(EEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                        
                        
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ldl) + scale(predicted_ldl) + scale(ldl_pgrs) + scale(EEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        
                        
summary(coxph(Surv(ttfu, event) ~ age + sex + scale(ratio) + scale(predicted_ratio) + #scale(EEAA) + 
                        neut + lymph + mono + eosin + baso, data=pg))                                                                        


cor(pg[,c("EEAA", "predicted_bmi", "predicted_smk", "predicted_alc", "predicted_ea", 
                      "predicted_tc", "predicted_hdl", "predicted_ldl", "predicted_ratio", 
                      "predicted_fat", "predicted_whr")], use="pairwise.complete.obs")
# Reviwer question about former smoker prediction
pg2 <- pg
pg2$smk_current_former <- pg$smk_current_never
